import { mergeProps, useSSRContext, defineComponent, computed, unref, ref, createSSRApp, h } from "vue";
import { renderToString } from "@vue/server-renderer";
import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate, ssrRenderList, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { useI18n, createI18n } from "vue-i18n";
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<main${ssrRenderAttrs(mergeProps({
    class: "demo",
    "data-demo": "true"
  }, _attrs))}><div id="reader-app"></div><div class="demo__panel"><p class="demo__status" data-demo-status role="status">Loading the sample comic…</p><p class="demo__error" data-demo-error hidden> The sample could not be downloaded. Check the connection and reload this page. </p><p class="demo__hint"> A public-domain comic opens automatically, so there is nothing to pick. <a href="/">Read your own file instead</a></p><p class="demo__credit"> “Little Nemo in Slumberland” — Sunday pages from 1908 by Winsor McCay, published in the New York Herald. Public domain in the United States (Wikimedia Commons template {{PD-US}}). <a href="https://commons.wikimedia.org/wiki/Category:Little_Nemo_in_Slumberland,_1908" rel="noopener">Source on Wikimedia Commons</a>. </p></div></main>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/DemoPage.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const DemoPage = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const SITE = {
  name: "CBZ Reader",
  tagline: "Read CBZ comics in your browser",
  description: "Open CBZ comic archives and convert CBZ to PDF in your browser. Files are unpacked on your device, never uploaded. Right-to-left manga and local reading progress."
};
const NAV = [
  { labelKey: "nav.reader", href: "/" },
  { labelKey: "nav.cbzToPdf", href: "/cbz-to-pdf/" },
  { labelKey: "nav.howToOpen", href: "/how-to-open-cbz/" },
  { labelKey: "nav.mangaMode", href: "/manga-reader/" },
  { labelKey: "nav.compare", href: "/cbz-vs-cbr/" }
];
const PAGES = [
  {
    path: "/",
    title: "CBZ Reader - Read and Convert CBZ Files in Your Browser",
    description: "Read CBZ comics and convert CBZ to PDF in your browser. Files stay on your device: no upload, no account. Manga right-to-left, spreads, zoom, and resume.",
    h1: "Read CBZ comics in your browser",
    eyebrow: "CBZ reader and converter",
    lead: "Open a CBZ to read, or convert it to PDF. Both run on your device.",
    tool: true,
    schema: "app",
    schemaFeatures: [
      "Open CBZ and ZIP comic archives locally",
      "Convert CBZ to PDF in the browser without uploading",
      "Right-to-left manga reading mode",
      "Single-page and double-page layouts",
      "Zoom and pan",
      "Local reading progress"
    ],
    updated: "2026-11-11",
    trust: ["Nothing is uploaded — the file stays in your browser, no account needed."],
    sections: [],
    faq: [
      {
        question: "Is my comic uploaded to a server?",
        answer: "No. The file is opened with the browser file picker and parsed in the page. Page images are decoded locally. Nothing is sent to this site or to a third party."
      },
      {
        question: "Does the reader work offline?",
        answer: "Yes, after the first visit. The page shell is kept by a service worker, so the reader can be reloaded without a connection, and your CBZ file is read from your device, so page turning does not need the network either. Pages you have never opened on this site are not stored, and a browser may drop its stored copy after a long period without visits; one online visit restores it."
      },
      {
        question: "Which formats are supported?",
        answer: "CBZ and ZIP archives that contain JPG, PNG, WebP, GIF, AVIF, or BMP pages. CBR and CB7 are on the roadmap but are not supported in this version."
      }
    ],
    tools: [
      {
        href: "/cbz-to-pdf/",
        label: "CBZ to PDF converter",
        note: "PDF with original sizes or A4.",
        kind: "tool"
      },
      {
        href: "/read-cbz-online/",
        label: "Read CBZ online",
        note: "What changes without uploads.",
        kind: "guide"
      },
      {
        href: "/manga-reader/",
        label: "Manga mode",
        note: "Right-to-left spreads in one tap.",
        kind: "guide"
      },
      {
        href: "/how-to-open-cbz/",
        label: "How to open a CBZ",
        note: "Desktop, Android, iPhone.",
        kind: "guide"
      },
      {
        href: "/what-is-a-cbz-file/",
        label: "What is a CBZ file?",
        note: "ZIP container, pages, metadata.",
        kind: "guide"
      },
      {
        href: "/cbz-file-format/",
        label: "Inside the CBZ format",
        note: "ComicInfo.xml, page order, layout.",
        kind: "guide"
      },
      {
        href: "/how-to-make-a-cbz-file/",
        label: "Make a CBZ",
        note: "Zip scans into a readable archive.",
        kind: "guide"
      },
      {
        href: "/cbz-file-wont-open/",
        label: "A CBZ that will not open",
        note: "Renamed RAR or encrypted.",
        kind: "guide"
      },
      {
        href: "/cbz-vs-cbr/",
        label: "CBZ vs CBR vs CB7",
        note: "Which containers browsers open.",
        kind: "guide"
      },
      {
        href: "/read-cbz-on-iphone/",
        label: "Read CBZ on iPhone",
        note: "Files app and Safari limits.",
        kind: "guide"
      },
      {
        href: "/read-cbz-on-android/",
        label: "Read CBZ on Android",
        note: "Downloads or Drive, no app.",
        kind: "guide"
      },
      {
        href: "/demo/",
        label: "Try a sample comic",
        note: "A public-domain comic, no file.",
        kind: "sample"
      }
    ],
    related: []
  },
  {
    path: "/read-cbz-online/",
    title: "Read CBZ Online Without Uploading the File",
    description: "Open a CBZ online in your browser without uploading it. Local unpacking, instant page access, and no account. Works on desktop and mobile.",
    h1: "Read CBZ online without uploading it",
    eyebrow: "No-upload online reader",
    lead: "An online CBZ reader usually means an upload, a queue, and a temporary link. This one opens the archive in your browser instead, so the file never leaves your device.",
    schema: "article",
    updated: "2026-11-11",
    sections: [
      {
        heading: 'What "online" should mean for a local file',
        paragraphs: [
          "You already have the comic. The only thing you need is a viewer. Sending a 600 MB archive to a stranger just to look at page one is unnecessary work for both sides.",
          "This reader uses the File API to read the archive from disk. The ZIP central directory gives the page list, and only the page you are looking at is decompressed. The rest of the archive stays on disk until you reach it."
        ]
      },
      {
        heading: "How to open your file",
        bullets: [
          "Open the CBZ Reader home page.",
          'Click "Open a CBZ file" and choose the archive, or drag it onto the reader.',
          "Wait for the page count, then read with the arrow keys, swipe, or the page slider.",
          "Come back later with the same file and the reader offers to resume at your last page."
        ]
      },
      {
        heading: "When a desktop browser is the better choice",
        paragraphs: [
          "Phones are fine for reading, but the file picker on iOS is a few taps deeper than on a desktop. If you are organising a library, testing a batch of archives, or reading a very large scan, a desktop browser with drag and drop is the fastest path."
        ]
      }
    ],
    faq: [
      {
        question: "Do I need to install anything?",
        answer: "No. It is a static website. There is no extension, no desktop app, and no sign-up."
      },
      {
        question: "Can I use it offline?",
        answer: "Once the page is loaded, the reader itself works without a network connection. Your comic is already local, so page turns do not depend on the server."
      },
      {
        question: "Why does the first page take a moment on a huge archive?",
        answer: "The browser has to read the archive directory and decode the first image. After that, nearby pages are preloaded in the background. On phones, very large pages are downsampled to stay inside the tab memory limit."
      }
    ],
    related: ["/", "/how-to-open-cbz/", "/what-is-a-cbz-file/", "/privacy/", "/cbz-to-pdf/"]
  },
  {
    path: "/manga-reader/",
    title: "CBZ Manga Reader with Right-to-Left Pages",
    description: "Read CBZ manga with right-to-left page order, double-page spreads, and a cover that stays on its own page. Local, no upload, works in your browser.",
    h1: "A CBZ manga reader that respects right-to-left pages",
    eyebrow: "Manga mode",
    lead: "Western comics read left to right. Manga does not. The reader detects the direction from ComicInfo.xml, and you can flip it with one tap when a file is tagged wrong.",
    schema: "article",
    updated: "2026-11-11",
    sections: [
      {
        heading: "Right-to-left is more than reversing the arrow keys",
        paragraphs: [
          "In a two-page spread, the earlier page belongs on the right. The cover is usually a single page, so pairing has to start after page one, not at page one. Getting this wrong makes every spread feel backwards even when the page numbers are correct.",
          'This reader keeps a cover offset in double-page mode, reverses the visual order for RTL, and maps the left tap zone to "next page" when RTL is on. The arrow keys follow the same rule.'
        ]
      },
      {
        heading: "How the direction is chosen",
        bullets: [
          "If ComicInfo.xml contains Manga = YesAndRightToLeft, the file opens in RTL mode.",
          "Otherwise the reader starts left to right.",
          "The RTL button in the toolbar overrides the guess for the current session.",
          "Your choice is saved with the reading progress for that file."
        ]
      },
      {
        heading: "Double-page spreads",
        paragraphs: [
          "Double-page mode is available on wide screens and can be toggled at any time. The cover is displayed alone by default, then pages pair as 2-3, 4-5, and so on. If a spread looks wrong, switch to single-page mode; automatic wide-page detection is planned but not part of this version."
        ]
      }
    ],
    faq: [
      {
        question: "How do I turn on right-to-left mode?",
        answer: "Open a file and press the RTL button in the toolbar. If the archive has a ComicInfo.xml with Manga = YesAndRightToLeft, it is already on."
      },
      {
        question: "Does it support double-page spreads?",
        answer: "Yes. Use the Single / Double button in the toolbar. The cover is kept as a single page, and the visual order follows the RTL setting."
      },
      {
        question: "Can I read vertical webtoon strips?",
        answer: "Yes. Switch the layout to Scroll in the toolbar and the pages line up in one continuous vertical column. Only a window of pages is kept in memory, so a long archive scrolls without loading every image, and pinch or Ctrl + wheel widens the column."
      }
    ],
    related: ["/", "/how-to-open-cbz/", "/cbz-vs-cbr/", "/cbz-to-pdf/"]
  },
  {
    path: "/how-to-open-cbz/",
    title: "How to Open a CBZ File on Windows, Mac, iPhone, and Android",
    description: "A CBZ file is a ZIP archive of comic pages. Learn how to open one on desktop or phone, with or without an app, and why page order sometimes breaks.",
    h1: "How to open a CBZ file",
    eyebrow: "Step-by-step guide",
    lead: "A .cbz file is not a special image format. It is a ZIP archive with comic pages inside, usually JPG or PNG, plus an optional metadata file. That is why almost anything that can open a ZIP can open a CBZ.",
    schema: "article",
    updated: "2026-11-11",
    sections: [
      {
        heading: "What is inside a CBZ file",
        paragraphs: [
          "Rename a .cbz to .zip and you can inspect it with any archive tool. You will usually find numbered images, sometimes a folder per chapter, and often a ComicInfo.xml file with the series name, volume, page count, and reading direction.",
          "Because the pages are ordinary images, the quality of the reading experience depends on the viewer: page sorting, memory use, and spread handling matter more than the container itself."
        ]
      },
      {
        heading: "Open a CBZ on Windows or Mac",
        bullets: [
          "Fastest, no install: open the CBZ Reader in your browser and drag the file onto the page.",
          "With an archive tool: rename a copy to .zip, extract it, and open the images in any image viewer.",
          "With a comic app: most comic readers accept CBZ directly and remember your page."
        ]
      },
      {
        heading: "Open a CBZ on iPhone or iPad",
        bullets: [
          "Save the file to the Files app first. Files stored only in iCloud Drive may need to be downloaded before they can be opened.",
          'Open the CBZ Reader in Safari, tap "Open a CBZ file", then pick the archive from Files.',
          "iOS does not let a website register as the default handler for .cbz, so you cannot long-press a file and choose the site. Opening the site first is the reliable route."
        ]
      },
      {
        heading: "Open a CBZ on Android",
        bullets: [
          "Open the site in Chrome and use the file picker, or drag the file in on a tablet.",
          "Adding the site to your home screen gives you a shortcut, but the site does not register a share target, so you still pick the file with the button.",
          "Android file pickers are generally more tolerant of the .cbz extension than iOS."
        ]
      },
      {
        heading: "Why the pages are out of order",
        paragraphs: [
          "Computers sort text alphabetically by default: 1.jpg, 10.jpg, 11.jpg, 2.jpg. Comic archives expect numeric order. A reader that does not use natural sorting will show page 10 before page 2. This reader sorts numerically and falls back to the full path when two files share a number."
        ]
      }
    ],
    faq: [
      {
        question: "Is CBZ the same as ZIP?",
        answer: "Yes, structurally. CBZ is a ZIP archive with a comic-specific extension. Some tools also add ComicInfo.xml for metadata. Renaming .cbz to .zip does not change the contents."
      },
      {
        question: "Can I open a CBZ with WinRAR or 7-Zip?",
        answer: "Yes. Both can extract the images. That is useful for inspecting a file, but it is not a comfortable way to read a 200-page comic."
      },
      {
        question: "Why does my reader show pages in the wrong order?",
        answer: 'It is almost always alphabetical sorting instead of natural sorting. Look for a "natural sort" or "numeric sort" option, or use a reader that sorts numbers correctly by default.'
      },
      {
        question: "Can I convert CBZ to PDF?",
        answer: "Yes. The converter on this site builds the PDF in the same tab, so the archive still stays on your device. This page covers reading; the conversion options are described on the converter page."
      }
    ],
    related: ["/", "/cbz-vs-cbr/", "/read-cbz-on-iphone/", "/read-cbz-on-android/", "/cbz-to-pdf/"]
  },
  {
    path: "/cbz-vs-cbr/",
    title: "CBZ vs CBR vs CB7: What Is the Difference?",
    description: "CBZ is ZIP, CBR is RAR, and CB7 is 7z. Compare compatibility, compression, licensing, and which format this browser reader supports today.",
    h1: "CBZ vs CBR vs CB7",
    eyebrow: "Format comparison",
    lead: "The three comic container formats differ mainly in which archive algorithm they use. That single difference decides which apps can open them, how fast a page can be reached, and whether a browser can read them at all.",
    schema: "article",
    updated: "2026-11-11",
    sections: [
      {
        heading: "The short version",
        bullets: [
          "CBZ = ZIP. The most compatible option and the easiest to read in a browser.",
          "CBR = RAR. Often slightly smaller, but requires a RAR decoder with a restrictive licence.",
          "CB7 = 7z. Good compression, less common for comics, and frequently uses solid blocks."
        ]
      },
      {
        heading: "Why CBR is harder in a browser",
        paragraphs: [
          "ZIP stores each file separately, and its directory sits at the end of the archive. A reader can jump straight to page 180. RAR supports solid compression, where many files are compressed as one stream. To reach page 180 in a solid archive, a decoder has to decompress everything before it.",
          "The decoder is also a licensing question. UnRAR is free to use for extraction but is not an OSI-approved open-source licence, and it forbids using the code to build a RAR compressor. That is manageable for a reader, but it needs care in a commercial product."
        ]
      },
      {
        heading: "What this reader supports",
        paragraphs: [
          "This version reads CBZ and ZIP. CBR and CB7 are not supported yet. The plan is to add them through a lazily loaded libarchive module, with a clear progress indicator for solid archives, rather than pretending a solid RAR can open instantly.",
          "If you have a CBR and need to read it here today, convert it to CBZ with a local tool first. Do not upload a copyrighted comic to a random converter."
        ]
      },
      {
        heading: "Which format should you keep?",
        paragraphs: [
          "For a personal library, CBZ is the safest default. It opens in more apps, on more devices, and in the browser without a native decoder. Use CBR or CB7 when the source only exists in that format, not as a deliberate archival choice."
        ]
      }
    ],
    faq: [
      {
        question: "Is CBR better than CBZ?",
        answer: "Not inherently. CBR often produces a smaller file, but compatibility is worse and solid archives can be slower to seek. For reading, CBZ is usually the better trade."
      },
      {
        question: "Can I convert CBR to CBZ?",
        answer: "Yes, with a local archive tool that can extract RAR. Extract the images, then zip them with the .cbz extension. Do not rename .cbr to .cbz; the bytes are still RAR and the file will not open."
      },
      {
        question: "Does this reader support CBR or CB7?",
        answer: "Not in this version. CBZ and ZIP are supported. CBR and CB7 are planned, with solid-archive progress and a graceful fallback for unsupported encryption."
      }
    ],
    related: ["/", "/cbz-file-format/", "/cbz-file-wont-open/", "/manga-reader/", "/cbz-to-pdf/"]
  },
  {
    path: "/what-is-a-cbz-file/",
    title: "What Is a CBZ File? Comic Book ZIP, Explained",
    description: "A CBZ is a ZIP archive of comic pages with a comic-specific extension. See what is inside, how to verify the file yourself, and which beliefs are wrong.",
    h1: "What is a CBZ file?",
    eyebrow: "File basics",
    lead: "A .cbz file is an ordinary ZIP archive with a comic-specific extension. Inside are page images, sometimes a metadata file, and nothing else. The extension is a naming convention, not a new kind of compression.",
    schema: "article",
    updated: "2026-11-11",
    sections: [
      {
        heading: "One sentence, then the details",
        paragraphs: [
          "CBZ stands for Comic Book Zip. The file is a ZIP archive whose extension has been changed from .zip to .cbz so that comic readers and file managers can recognise it. Rename it back to .zip and every archive tool opens it without complaint.",
          "There is no standards body behind CBZ. The extension was popularised by early Windows comic readers such as CDisplay, which paired .cbz with .cbr (a RAR archive) and told the operating system which app should open them. Modern readers follow the same convention because it is simple and self-describing."
        ]
      },
      {
        heading: "What is usually inside",
        bullets: [
          "Page images in reading order, most often JPEG. PNG, WebP, GIF, AVIF, and BMP also appear. This reader accepts those six types and ignores everything else in the archive.",
          "An optional ComicInfo.xml with series name, volume, page count, and reading direction. It is metadata only: a CBZ without it still reads fine.",
          "Sometimes one folder per chapter, a cover image, or a credits page. Nothing in the format requires a flat structure.",
          "No database, no index, no DRM. The archive is the whole book."
        ]
      },
      {
        heading: "How to confirm a file really is a CBZ",
        paragraphs: [
          "If a file refuses to open, check the bytes before blaming the reader. A real ZIP starts with the characters PK. On Windows, renaming a copy to .zip and double-clicking is the fastest test. On macOS or Linux, `unzip -l file.cbz` lists the contents and `file file.cbz` prints the container type.",
          "A file whose header is Rar! or 7z was simply renamed, and no CBZ reader can open it. A file that turns out to be HTML is usually an error or login page that the browser saved under the archive name."
        ]
      },
      {
        heading: "Beliefs worth dropping",
        bullets: [
          "“CBZ is an image format.” It is a container. Sharpness and colour depend entirely on the images packed into it.",
          "“A CBZ must include ComicInfo.xml.” It is optional. When present, only two things change here: the title and the right-to-left hint.",
          "“CBZ files are encrypted.” The container has no DRM. Individual ZIP entries can be password-protected, but that is a ZIP feature, not a comic one, and this reader refuses those archives with a clear message.",
          "“Renaming CBR to CBZ converts it.” It does not. The bytes stay RAR and the file stays unreadable as a ZIP.",
          "“CBZ is safer than other archives.” A ZIP cannot run code by itself, but it can contain anything. Where the file came from matters more than the extension."
        ]
      },
      {
        heading: "Where the name comes from",
        paragraphs: [
          "CDisplay, a small Windows viewer from the early 2000s, used .cbz and .cbr so that double-clicking a comic opened the right program. The names stuck because every later reader wanted the same file associations.",
          "Today the extension is mostly a signal between you and your software. The bytes are ZIP, which is why a browser can read a CBZ without a plugin: it only has to unzip the archive and decode images."
        ]
      }
    ],
    faq: [
      {
        question: "Is a CBZ file the same as a ZIP file?",
        answer: "Structurally yes. Same header, same directory, same compression. Only the extension and the convention around it differ."
      },
      {
        question: "Do I need an app to open a CBZ?",
        answer: "No. A browser reader can unpack and display it locally, and archive tools can extract it. A dedicated app adds library management and file association, not format support."
      },
      {
        question: "Why does my CBZ show a blank icon?",
        answer: "No application on that system claims the .cbz extension. The file is still valid; assign a reader, or open the site first and pick the file."
      },
      {
        question: "Does packing pages into a CBZ reduce quality?",
        answer: "No, as long as the images are stored or deflated and not re-encoded. Quality drops only if a tool re-saves the JPEGs. ZIP compression itself is lossless."
      },
      {
        question: "Can a CBZ contain PDF pages?",
        answer: "No reader treats a PDF as a page image. Some archives include PDF extras, but this reader lists only JPG, PNG, WebP, GIF, AVIF, and BMP."
      }
    ],
    related: ["/cbz-file-format/", "/how-to-open-cbz/", "/how-to-make-a-cbz-file/", "/cbz-vs-cbr/", "/cbz-to-pdf/"]
  },
  {
    path: "/cbz-file-format/",
    title: "CBZ File Format: ZIP Layout, ComicInfo.xml, and Page Order",
    description: "How a CBZ works inside: ZIP central directory, store vs deflate, filename sorting, ComicInfo.xml, and the archives a browser cannot open.",
    h1: "The CBZ file format, from the bytes up",
    eyebrow: "Format internals",
    lead: "CBZ has no specification document. What it has is the ZIP specification plus a set of community conventions. Knowing both explains why one comic opens instantly and another stalls at page one.",
    schema: "article",
    updated: "2026-11-11",
    sections: [
      {
        heading: "A naming convention, not a spec",
        paragraphs: [
          "There is no RFC and no committee. A CBZ is a ZIP archive. The ComicInfo.xml metadata file and the idea of numbered pages come from the ComicRack ecosystem and are followed by most readers. That looseness is why two files with the same extension can behave very differently."
        ]
      },
      {
        heading: "The ZIP layout that makes seeking cheap",
        paragraphs: [
          "A ZIP contains local file headers, each followed by compressed data, plus a central directory at the end that lists every entry and its offset. A reader reads the tail first, builds the page index, then jumps to the exact byte range of the page it needs. Page 180 costs about the same as page 2.",
          "This is also why solid RAR archives are a poor fit for reading: one compressed stream means everything before page 180 must be decompressed first. ZIP does not have that restriction, and CBZ inherits the advantage.",
          "ZIP64 takes over above 4 GiB or 65,535 entries. Most comic archives stay below both, but a full scan run packed into one file can cross the first limit, and older tools may produce an archive that a reader opens incorrectly."
        ]
      },
      {
        heading: "Compression methods: store or deflate",
        paragraphs: [
          "The ZIP specification allows many methods. In practice, comic archives use two: store (method 0) and deflate (method 8). Page images are already compressed, so deflate usually saves very little while costing CPU time on every page open. Many tools store JPEG pages verbatim for that reason.",
          "Other methods exist — bzip2, LZMA, PPMd — and a ZIP using them is still a valid ZIP. Browser-based readers cannot unpack those, which is one reason a CBZ can open on the desktop and fail in a tab."
        ]
      },
      {
        heading: "Page order is a naming convention",
        paragraphs: [
          "The format stores filenames, not page numbers. Readers sort image entries with a natural comparison, so 2.jpg precedes 10.jpg. Zero-padded names such as 001.jpg make the order unambiguous even for tools that sort as plain text.",
          "Folders are usually flattened: chapter 1/001.jpg and chapter 2/001.jpg become consecutive pages in path order. Two files with the same basename fall back to comparing the full path.",
          "Build scripts and macOS add junk entries: __MACOSX folders, .DS_Store, Thumbs.db. This reader filters them out; a reader that does not will show duplicate or blank pages."
        ]
      },
      {
        heading: "ComicInfo.xml",
        paragraphs: [
          "An optional XML file, normally at the archive root, describing the book. The fields that matter for reading are Series, Number, Volume, Title, PageCount, Summary, Year, LanguageISO, BlackAndWhite, and Manga. Manga accepts Yes, No, or YesAndRightToLeft.",
          "This reader uses only Manga and the series/number pair. A malformed or missing file degrades to a neutral title and left-to-right pages instead of an error, because metadata should never block reading."
        ]
      },
      {
        heading: "Encoding and filename quirks",
        paragraphs: [
          "ZIP filenames are bytes. General purpose bit 11 marks a name as UTF-8; without it, old tools wrote CP437 and accented titles turn into mojibake. macOS also stores names in decomposed Unicode, so the same Japanese title can look identical on screen and still compare differently.",
          "None of this changes the images, but it can change sort order and the title shown in the toolbar."
        ]
      },
      {
        heading: "What a browser cannot open",
        paragraphs: [
          "Password-protected entries (ZipCrypto or AES-256), split or multi-volume archives (.z01, .z02), entries compressed with an unsupported method, and RAR or 7z files renamed to .cbz. This reader reports the encrypted and no-image cases explicitly instead of showing a blank page."
        ]
      }
    ],
    faq: [
      {
        question: "Is CBZ an official format?",
        answer: "No. It is a widely followed convention: ZIP plus comic pages, with optional ComicInfo.xml metadata. Nothing enforces the layout, which is why readers vary."
      },
      {
        question: "Does the compression method affect image quality?",
        answer: "No. Store and deflate are both lossless. Quality changes only if a tool re-encodes the JPEGs inside the archive."
      },
      {
        question: "Why do my pages appear as 1, 10, 2?",
        answer: "The packing tool or the reader sorted names as plain text. Rename with zero-padded numbers (001, 002, … 010) or use a reader that sorts numbers naturally."
      },
      {
        question: "Can I put video or PDF files in a CBZ?",
        answer: "You can put anything in a ZIP, but a comic reader ignores non-image entries. This one lists only JPG, PNG, WebP, GIF, AVIF, and BMP."
      },
      {
        question: "What is the difference between CBZ and CB7?",
        answer: "CBZ wraps ZIP, CB7 wraps 7z. CB7 compresses better and is less common; browsers have no built-in 7z decoder, so CB7 stays a desktop-app format for now."
      }
    ],
    related: ["/what-is-a-cbz-file/", "/cbz-vs-cbr/", "/cbz-file-wont-open/", "/how-to-make-a-cbz-file/", "/cbz-to-pdf/"]
  },
  {
    path: "/read-cbz-on-iphone/",
    title: "How to Read a CBZ File on iPhone and iPad",
    description: "Open CBZ comics on iPhone or iPad with the Files app and Safari. Covers iCloud download checks, renaming a ZIP to CBZ on iOS, and Safari memory limits.",
    h1: "Read a CBZ file on iPhone or iPad",
    eyebrow: "iOS guide",
    lead: "iOS has no built-in handler for .cbz, so tapping the file in Files does nothing useful. The reliable route is the reverse: open the reader in Safari first, then pick the archive from the Files browser.",
    schema: "article",
    updated: "2026-11-11",
    sections: [
      {
        heading: "Why tapping the file does nothing",
        paragraphs: [
          "iPhone and iPad ship with viewers for PDF, images, and office documents, but not for comic archives. No system app claims .cbz, and a website cannot register itself as the handler for a file type. A tap offers sharing options, not reading.",
          "Quick Look can preview individual images after you extract an archive, which is not the same as reading a comic in order."
        ]
      },
      {
        heading: "Step by step",
        bullets: [
          "Get the file into the Files app: from Mail, tap the attachment and choose Save to Files; from a computer, use AirDrop; from a cloud provider, open it in Files.",
          "Check that it is really downloaded. An iCloud item with a cloud icon is a placeholder, and the picker will stall or refuse until it is local. Tap the cloud icon first.",
          "Open this site in Safari, tap Choose a CBZ file, then Browse and pick the archive from On My iPhone or iCloud Drive.",
          "If the file arrived as a .zip, rename it in Files (long-press, Rename, replace .zip with .cbz). The bytes are already a ZIP, so no conversion is needed.",
          "Add the site to your Home Screen if you expect to come back. It still opens the same picker, but saves typing the address."
        ]
      },
      {
        heading: "Where the file can live",
        paragraphs: [
          "On My iPhone is the simplest location because it is always local. iCloud Drive works, but only after the file is downloaded. External drives and SD cards appear in Files on modern iOS and iPadOS, which is useful for large scan archives that would otherwise fill local storage.",
          "Third-party providers such as Dropbox or Google Drive appear in the Files browser once their Files extension is enabled. Picking from one may trigger a download before the reader can open the archive."
        ]
      },
      {
        heading: "iOS limits you will actually notice",
        bullets: [
          "No file association for .cbz, so the site has to be opened first. This is an OS rule, not a site limitation.",
          "The file picker filters by declared types. iOS greys out files when the filter is too specific, so this reader relaxes the filter on iOS and shows every file instead.",
          "Safari gives each tab a memory budget. Very large pages are downsampled before display; without that, a 5000-pixel scan can exhaust a phone tab.",
          "Switching apps under memory pressure can discard the page. Reading progress is stored locally and restored, but the browser is not allowed to reopen your file by itself, so you pick it again.",
          "Private browsing can clear local progress when the session ends."
        ]
      },
      {
        heading: "iPad specifics",
        paragraphs: [
          "Wide screens make double-page mode useful, and an external keyboard gives you arrow-key page turns. Split View and Slide Over shrink the memory available to the tab, so a huge archive is more likely to be reloaded there than in full screen."
        ]
      },
      {
        heading: "When a native app is the better tool",
        paragraphs: [
          "If you keep a large library on the device, a native comic app handles file association, folders, and offline covers better. A browser reader is for opening one file quickly, on a device where you do not want to install or sign in to anything."
        ]
      }
    ],
    faq: [
      {
        question: "Can I open a CBZ in Apple Books?",
        answer: "No. Books handles PDF and EPUB. A CBZ is an image archive and needs a reader that understands ZIP containers."
      },
      {
        question: "Why is my file greyed out in the picker?",
        answer: "Most often it is an iCloud placeholder that has not been downloaded. Tap the cloud icon in Files, then pick it again."
      },
      {
        question: "Can I read straight from iCloud Drive?",
        answer: "Yes, after the file is downloaded to the device. The browser only receives the file when the provider hands over the bytes."
      },
      {
        question: "Is my progress synced between iPhone and iPad?",
        answer: "No. Progress lives in the browser profile on each device; there is no account and no sync."
      },
      {
        question: "Does it work in Chrome or Firefox on iOS?",
        answer: "Those browsers use the same WebKit engine and file picker as Safari, so the steps are identical, but Safari is the best-tested path."
      }
    ],
    related: ["/read-cbz-on-android/", "/how-to-open-cbz/", "/what-is-a-cbz-file/", "/cbz-file-wont-open/", "/cbz-to-pdf/"]
  },
  {
    path: "/read-cbz-on-android/",
    title: "How to Read a CBZ File on Android",
    description: "Read CBZ comics on Android from Downloads, SD cards, or cloud providers. Covers Chrome file picking, the .cbz filter workaround, and tab memory on phones.",
    h1: "Read a CBZ file on Android",
    eyebrow: "Android guide",
    lead: "Android has no default comic handler either, but its document picker is more forgiving than iOS: the file usually sits in Downloads, and Chrome hands it to the page in two taps.",
    schema: "article",
    updated: "2026-11-11",
    sections: [
      {
        heading: "Android already treats it as an archive",
        paragraphs: [
          "Android identifies files by MIME type, and .cbz has no registered type. The system usually falls back to a generic ZIP or binary type, both of which Chrome can pass to a web page. That is why Android rarely blocks a CBZ the way iOS does.",
          "Nothing is installed and no storage permission is requested: the picker grants the page read access to exactly the file you choose."
        ]
      },
      {
        heading: "Step by step",
        bullets: [
          "Download the archive, or move it into Downloads from a chat app or cloud drive.",
          "Open this site in Chrome, tap Choose a CBZ file, then pick the file under Downloads, Recent, or your SD card.",
          "If the entry is greyed out, the picker is filtering on a MIME type it cannot map. Rename a copy to .zip, which every Android build recognises, or open it from a file manager that reports ZIP.",
          "Add the site to your Home Screen for quicker access. It still opens the same picker; the site does not register a share target."
        ]
      },
      {
        heading: "Where Android files usually are",
        paragraphs: [
          "Downloads is the default target for Chrome. Chat apps keep files in their own folders, which the picker can still reach. SD cards and USB drives appear as separate roots. Google Drive and other providers show up through the system picker once their app is installed, and a large file may need to download locally first.",
          "Scoped storage on Android 11 and later hides other apps’ private directories from file managers, but it does not affect a file you pick yourself."
        ]
      },
      {
        heading: "Zip handling on the device",
        paragraphs: [
          "Files by Google and most OEM file managers can extract a ZIP and rename files. To turn a folder of images into a CBZ on the phone, compress the images and rename the result from .zip to .cbz; the extension is the only difference.",
          "Some managers hide extensions by default. If the rename produces .zip.cbz, the real name is now wrong; enable extension display and rename again."
        ]
      },
      {
        heading: "Android vs iPhone in practice",
        bullets: [
          "Getting the file in: Android is usually one download away; iOS often needs Save to Files plus an iCloud download check.",
          "File association: neither OS opens .cbz on double-tap, so both routes start at the site.",
          "External storage: Android is more direct with SD cards and USB drives; iOS supports them through Files but with more steps.",
          "Memory: low-RAM Android phones and older iPads both reload heavy tabs. Downsampling keeps a large page inside the tab budget on either platform.",
          "Gestures: Android back closes the menu or leaves the reader, while the iOS back gesture belongs to Safari and behaves differently."
        ]
      },
      {
        heading: "Tablets, foldables, and keyboards",
        paragraphs: [
          "On a wide screen, double-page mode pairs spreads after the cover, and arrow keys from an external keyboard turn pages. Split-screen reduces available memory, so keep very large archives in full-screen mode."
        ]
      }
    ],
    faq: [
      {
        question: "Do I need a file manager on Android?",
        answer: "No. Chrome’s picker reaches Downloads, Recent, and most cloud providers. A file manager helps when a file is buried in an app-specific folder."
      },
      {
        question: "Why does the reader say no readable images?",
        answer: "The archive may contain TIFF, HEIC, JXL, or PDF pages, which browsers cannot display, or the images may be encrypted. Convert pages to JPEG or PNG first."
      },
      {
        question: "Can I read a CBZ from Google Drive directly?",
        answer: "Yes if the provider hands the file to the picker. Large archives may download to local storage first, because the page needs the bytes, not a link."
      },
      {
        question: "Does it work offline on Android?",
        answer: "There is no app and no service worker in this version, so reloading the page needs a network connection. Once the reader is loaded, page turns are local."
      },
      {
        question: "Why does the tab reload when I switch apps?",
        answer: "Android reclaims memory from background tabs. Progress is saved, but you have to pick the file again because a page cannot reopen a local file by itself."
      }
    ],
    related: ["/read-cbz-on-iphone/", "/how-to-open-cbz/", "/what-is-a-cbz-file/", "/cbz-file-wont-open/", "/cbz-to-pdf/"]
  },
  {
    path: "/how-to-make-a-cbz-file/",
    title: "How to Make a CBZ File from Images or a Folder",
    description: "Build a CBZ the right way: zero-padded page names, ZIP settings that avoid wasted CPU, optional ComicInfo.xml, and packing mistakes that break page order.",
    h1: "How to make a CBZ file",
    eyebrow: "Packing guide",
    lead: "Making a CBZ is making a ZIP with the right name. The work is not in the compression; it is in page naming, folder structure, and metadata that readers will actually use.",
    schema: "article",
    updated: "2026-11-11",
    sections: [
      {
        heading: "The whole job in one line",
        paragraphs: [
          "Collect the page images, put them into one archive in reading order, and name the archive with a .cbz extension. Any ZIP tool can do it; no comic-specific software is required."
        ]
      },
      {
        heading: "Name pages so they sort correctly",
        bullets: [
          "Zero-pad to a fixed width: 001.jpg through 120.jpg. Without padding, 10.jpg sorts before 2.jpg in plain text order.",
          "Keep one naming pattern. Mixing page-1.jpg with p10.png and scan_011 forces every reader to guess.",
          "Use chapter folders only if the reader flattens paths predictably. This one sorts by file name first, then by full path.",
          "Avoid duplicate numbers. Two files named 012.jpg in different folders are ambiguous by design."
        ]
      },
      {
        heading: "Zip it without wasting time",
        bullets: [
          "JPEG and PNG pages are already compressed. Deflate on top saves a few percent and costs CPU on every page open; choose Store when your tool offers it.",
          "Archive the images themselves, not the folder that contains them. Most readers flatten a single wrapper folder, but the extra level makes debugging harder.",
          "Exclude macOS resource forks (__MACOSX), .DS_Store, Thumbs.db, and cover thumbnails you do not want as pages.",
          "Do not add a password. Browsers have no prompt for ZIP passwords, so an encrypted CBZ is unreadable in a tab.",
          "Windows: select the images, right-click, Send to, Compressed folder, then rename .zip to .cbz. macOS: select the images and use Compress; compressing a folder instead adds one nested directory."
        ]
      },
      {
        heading: "Add ComicInfo.xml only if it helps",
        paragraphs: [
          "A minimal file at the archive root is enough: a ComicInfo element with Series, Number, PageCount, and Manga. Series and Number become the title, and Manga set to YesAndRightToLeft switches the initial reading direction.",
          "Wrong metadata is worse than none: a stale PageCount or a wrong Manga value changes what the reader shows. Most readers ignore unknown tags, so keep the file small."
        ]
      },
      {
        heading: "Check the archive before you share it",
        bullets: [
          "Rename a copy to .zip and open it: the page count should match, the first and last pages should be present, and no thumbnails should appear in the middle.",
          "Open it in a reader and jump to a middle page. A missing central directory or a truncated file usually fails at open time, not at page 40.",
          "Spot-check a spread. Two-page spreads scanned as one image will look wrong in double-page mode."
        ]
      },
      {
        heading: "Common packing mistakes",
        bullets: [
          "Re-saving JPEGs instead of copying them, which lowers quality with every pass.",
          "Mixing page sizes wildly; the reader has to rescale each page and the reading rhythm suffers.",
          "Leaving an .exe or readme inside. It is harmless to the reader, but it makes the archive look untrustworthy.",
          "Assuming a PDF belongs in a CBZ. A PDF is not a page image and will be ignored."
        ]
      }
    ],
    faq: [
      {
        question: "Do I need special software to make a CBZ?",
        answer: "No. Any ZIP tool plus a rename works. Dedicated comic tools add metadata editing and batch naming, not a different format."
      },
      {
        question: "Does zipping lower image quality?",
        answer: "No. ZIP is lossless. Quality drops only if a tool re-encodes the images before packing."
      },
      {
        question: "Can I make a CBZ on a phone?",
        answer: "Yes. Files by Google and iOS Files can compress selected files; rename the result to .cbz. Long archives are easier to verify on a desktop."
      },
      {
        question: "Should I use CBZ or PDF for scans?",
        answer: "CBZ for reading: pages stay separate, seeking is cheap, and readers handle right-to-left order. PDF suits printing and text-heavy documents."
      },
      {
        question: "Can this site create a CBZ for me?",
        answer: "No. It only reads archives; repacking happens in your file manager or archive tool."
      }
    ],
    related: ["/what-is-a-cbz-file/", "/cbz-file-format/", "/cbz-file-wont-open/", "/how-to-open-cbz/", "/cbz-to-pdf/"]
  },
  {
    path: "/cbz-file-wont-open/",
    title: "CBZ File Won’t Open? Causes and Fixes",
    description: "Diagnose a CBZ that will not open: renamed RAR, truncated download, encrypted entries, unsupported image types, and picker problems on phones.",
    h1: "Why a CBZ file will not open",
    eyebrow: "Troubleshooting",
    lead: "Most broken CBZ files are not broken archives. They are a RAR renamed, a download saved as an error page, or a folder of images the reader cannot decode. A few checks separate those cases quickly.",
    schema: "article",
    updated: "2026-11-11",
    sections: [
      {
        heading: "Check the container first",
        paragraphs: [
          "Look at the first bytes. A ZIP starts with PK, RAR starts with Rar!, 7z starts with 7z. If the header is HTML, you saved a login or error page under the archive name. On macOS or Linux, `file` and `unzip -l` answer this in one command; on Windows, rename a copy to .zip and try to open it.",
          "A zero-byte file, or one far smaller than the original download, means the transfer never finished."
        ]
      },
      {
        heading: "The archive is truncated or corrupted",
        paragraphs: [
          "A ZIP keeps its index at the end. If the last bytes are missing, the reader cannot list the pages and reports an invalid archive even though the first images are intact. Download again, ideally without a manager that splits the file, and compare the size with the source.",
          "If the file opens but one page fails, that entry is damaged; `unzip -t` names it."
        ]
      },
      {
        heading: "It is actually RAR or 7z",
        paragraphs: [
          "Renaming does not convert. Extract the archive with a tool that understands RAR or 7z, then pack the images into a ZIP and rename it .cbz. This reader does not support CBR or CB7."
        ]
      },
      {
        heading: "The archive is encrypted",
        paragraphs: [
          "A ZIP can protect entries with a password. A browser tab has no place to type it, so this reader stops with a password-protected message instead of showing blank pages. Remove the password in 7-Zip or a similar tool, then reopen the archive."
        ]
      },
      {
        heading: "The images are in a format a browser cannot show",
        paragraphs: [
          "This reader accepts JPG, PNG, WebP, GIF, AVIF, and BMP. TIFF, JPEG 2000, HEIC, and JPEG XL are common in scans and are not decoded by the page. Convert those pages to JPEG or PNG, then repack.",
          "Some CMYK JPEGs display with different colours in a browser because colour conversion is left to the browser. Re-exporting the pages as sRGB avoids the surprise."
        ]
      },
      {
        heading: "The pages are there but out of order, or some are missing",
        paragraphs: [
          "Alphabetical sorting puts 10 before 2. If the reader has no natural-sort option, rename with zero-padded numbers. Duplicate names across chapter folders also confuse the order, and an archive that mixes images with thumbnails can show what looks like a missing page."
        ]
      },
      {
        heading: "It works on a computer but not on a phone",
        bullets: [
          "iOS: the file may still be an iCloud placeholder, so it is greyed out or fails to open. Download it in Files first.",
          "Android: the picker may filter .cbz by MIME type. Pick it from Downloads, or rename a copy to .zip.",
          "Both: very large pages can exhaust a phone tab. Pages are downsampled automatically, but an archive with hundreds of huge pages can still be slow to open."
        ]
      },
      {
        heading: "Narrowing it down",
        paragraphs: [
          "Try the same file in another reader. If it fails there too, the archive is the problem. If it opens elsewhere but not here, check the image formats and encryption, which are the two limits this reader enforces."
        ]
      }
    ],
    faq: [
      {
        question: "Can a corrupted CBZ be repaired?",
        answer: "Sometimes. ZIP repair tools can recover intact entries and rebuild the index. If the central directory is gone, extracting what remains and repacking is usually faster than repairing."
      },
      {
        question: "Why does the file open in an archive tool but not in a reader?",
        answer: "Archive tools show bytes; readers need supported image entries in a readable order. Encrypted entries, TIFF or HEIC pages, and PDF-only archives all fail in a reader."
      },
      {
        question: "Is it safe to open a CBZ?",
        answer: "The format cannot execute code. Risk comes from where the file was downloaded and from executables bundled inside it, not from the ZIP itself. This site only reads image entries."
      },
      {
        question: "Why is my file greyed out on iPhone or Android?",
        answer: "On iOS it is usually an iCloud file that has not been downloaded. On Android it is usually a picker MIME filter; picking from Downloads or renaming to .zip works around it."
      },
      {
        question: "Can I open a split CBZ (.z01, .z02)?",
        answer: "Not in a browser. Multi-volume ZIP needs every part joined, and this reader expects a single archive."
      }
    ],
    related: ["/how-to-open-cbz/", "/cbz-vs-cbr/", "/cbz-file-format/", "/read-cbz-on-android/", "/cbz-to-pdf/"]
  },
  {
    path: "/privacy/",
    title: "Privacy - CBZ Reader",
    description: "CBZ Reader processes files locally in your browser. No uploads, no account, no cookies, and only cookie-free visit statistics.",
    h1: "Privacy",
    eyebrow: "Plain language",
    lead: "The short version: your comic never leaves your device, this site does not ask for an account, and the visit statistics it keeps are cookie-free and aggregate.",
    contact: "jiamin.wu23@mavi.help",
    schema: "article",
    updated: "2026-11-11",
    sections: [
      {
        heading: "Files",
        paragraphs: [
          "Comic archives are opened with the browser File API and parsed in the page. Page images are decoded locally. There is no upload endpoint, no server-side conversion, and no copy of your file stored by this site.",
          "Reading progress is stored in your browser IndexedDB, keyed by a fingerprint derived from the file name, size, and a hash of the first and last 64 KB. It stays on your device and can be removed by clearing site data."
        ]
      },
      {
        heading: "Analytics and cookies",
        paragraphs: [
          "Two cookie-free measurement tools are in use: Cloudflare Web Analytics, provided by the host, and Umami. Neither sets cookies, fingerprints devices, nor follows you across other sites. They are used to count page views and see which pages and features are actually used.",
          "Umami records page views plus a small set of coarse interaction events: a file was opened (with its extension and size range), the first page finished rendering (with timing), a layout mode was chosen, the first zoom, a bookmark was added, whether a recently opened file was resumed, and clicks on the reader button or related links. An event carries only its name and a few aggregate properties such as mode or size range. File names, page images, bookmark contents, and anything that could identify a person are never sent."
        ]
      },
      {
        heading: "Third parties",
        paragraphs: [
          "Pages load one third-party script: the Umami tracker from cloud.umami.is, identified by a public website ID. Cloudflare Web Analytics is supplied by the hosting provider. The site does not load remote fonts, remote images, embedded players, or advertising scripts, and it does not sell or share data with anyone else."
        ]
      },
      {
        heading: "Contact",
        contact: true,
        paragraphs: [
          "For privacy questions, corrections, or removal requests, write to the address below.",
          "This page is a technical description of the current build, not legal advice."
        ]
      }
    ],
    faq: [
      {
        question: "Do you keep my comics?",
        answer: "No. There is no upload. The file is read from your disk inside the browser tab."
      },
      {
        question: "Can I delete my reading history?",
        answer: "Yes. Clear site data for this domain in your browser settings. That removes the locally stored page markers and settings."
      },
      {
        question: "Do you use cookies?",
        answer: "No. The reader uses IndexedDB for local progress, which is not a cookie and is not sent to a server. Both analytics tools are cookie-free as well."
      }
    ],
    related: ["/", "/read-cbz-online/", "/how-to-open-cbz/", "/terms/", "/disclaimer/"]
  },
  {
    path: "/terms/",
    title: "Terms of Use - CBZ Reader",
    description: "The terms that apply to this browser-based CBZ reader and converter: as-is service, local file processing, acceptable use, and liability limits.",
    h1: "Terms of Use",
    eyebrow: "Legal",
    lead: "These terms cover your use of this site and its CBZ reader and converter. By using the site, you accept them.",
    contact: "jiamin.wu23@mavi.help",
    legal: true,
    schema: "article",
    updated: "2026-11-11",
    sections: [
      {
        heading: "The service",
        paragraphs: [
          'This site is a browser-based tool for reading CBZ archives and converting them to PDF. It is provided on an "as is" and "as available" basis. The operator does not promise that it will always be available, uninterrupted, or free of errors, and may change or discontinue it at any time.',
          "No account is required to use the features described on this site."
        ]
      },
      {
        heading: "Your files",
        paragraphs: [
          "Files you open or convert are read by your browser and processed inside the page. They are not uploaded to, stored on, or backed up by this site.",
          "You are responsible for making sure you have the right to open, convert, and use every file you load. Do not use this site for copyright infringement, for material you are not allowed to hold, or for any other unlawful purpose."
        ]
      },
      {
        heading: "No warranty",
        paragraphs: [
          "The site and its output are provided without warranties of any kind, express or implied, including fitness for a particular purpose and non-infringement. A conversion may fail, re-encode some image formats, or produce a file that another application reads differently; check the result before relying on it."
        ]
      },
      {
        heading: "Limitation of liability",
        paragraphs: [
          "To the extent permitted by law, the operator is not liable for data loss, corrupted output, lost profits, or any indirect or consequential loss arising from the use of, or inability to use, this site. Keep your own copies of important files.",
          "Nothing in these terms excludes liability that cannot be excluded under applicable law, or limits rights that mandatory consumer law gives you."
        ]
      },
      {
        heading: "Changes and governing law",
        paragraphs: [
          "These terms may be updated as the site changes. The revision date at the top of this page reflects the current version, and continued use after an update means you accept the revised terms.",
          "These terms are governed by the laws applicable at the operator's place of business, without regard to conflict-of-law rules. Disputes are subject to the competent courts there, unless mandatory law provides otherwise."
        ]
      },
      {
        heading: "Contact",
        contact: true,
        paragraphs: ["Questions about these terms can be sent to the address below."]
      }
    ],
    faq: [],
    related: ["/privacy/", "/disclaimer/", "/"]
  },
  {
    path: "/disclaimer/",
    title: "Disclaimer - CBZ Reader",
    description: "CBZ Reader is an independent local tool. It is not affiliated with any comic publisher or platform, and it does not host or distribute comic content apart from one credited public-domain sample.",
    h1: "Disclaimer",
    eyebrow: "Legal",
    lead: "This site is an independent tool for files you already have. It is not a comic platform and has no relationship with the companies that publish or sell comics.",
    legal: true,
    schema: "article",
    updated: "2026-11-11",
    sections: [
      {
        heading: "No affiliation or endorsement",
        paragraphs: [
          "This site is not affiliated with, authorized by, sponsored by, or endorsed by any comic publisher, distributor, storefront, scanlation group, or reading platform. Any similarity in naming is descriptive only."
        ]
      },
      {
        heading: "Trademarks and format names",
        paragraphs: [
          "Names such as CBZ, CBR, and PDF, along with any product or company names mentioned on this site, are the property of their respective owners and are used only to describe file formats and compatibility."
        ]
      },
      {
        heading: "No comic content is hosted",
        paragraphs: [
          "This site does not distribute, host, index, or provide links to comic books or any other copyrighted works. There is no library, no catalogue, and no search for titles. The only files it handles are the ones you open from your own device.",
          "The single exception is the built-in public-domain sample on the sample page: a classic comic whose copyright has expired, included with its title, author, licence, and source credited. It is there so the reader can be tried without a file; it is not a catalogue or a library."
        ]
      },
      {
        heading: "Local processing only",
        paragraphs: [
          "Reading and conversion run inside your browser tab. The site has no server-side copy of your files and no way to recover a file you closed or deleted."
        ]
      },
      {
        heading: "Third-party links",
        paragraphs: [
          "Some pages link to third-party sites for reference. Those sites are outside its control, their content may change, and a link is not an endorsement. Their own terms and privacy practices apply when you visit them."
        ]
      }
    ],
    faq: [],
    related: ["/terms/", "/privacy/", "/"]
  },
  {
    path: "/cbz-to-pdf/",
    title: "CBZ to PDF Converter - Local, No Upload",
    description: "Convert a CBZ comic archive to PDF in your browser. Nothing is uploaded, JPEG pages are copied unchanged, and pages keep their original size or fit A4.",
    h1: "Convert CBZ to PDF without uploading",
    eyebrow: "CBZ to PDF",
    lead: "Pick a .cbz file and get a PDF back without a round trip to a server. The archive is unpacked and the PDF is assembled in this tab, so the pages never leave your device.",
    converter: true,
    trust: ["No upload", "JPEG pages copied as-is", "Original size or A4", "Works offline"],
    schema: "app",
    schemaFeatures: [
      "Convert a CBZ archive to PDF in the browser",
      "JPEG pages embedded without re-encoding",
      "Original image size or A4 pages",
      "No upload and no account",
      "Cancelable conversion with specific error messages"
    ],
    updated: "2026-11-11",
    sections: [
      {
        heading: "Why most CBZ to PDF converters upload your file",
        paragraphs: [
          "Uploading is the simplest way to build this tool. The archive goes to a server, a machine with a PDF library and plenty of memory unpacks it, and the finished file comes back as a download link. The browser only has to send and receive bytes.",
          "That design suits the operator, not the reader. A copy of your comic exists somewhere else even if it is deleted an hour later, large files usually need an account or a paid tier, and the result depends on someone else keeping the service online. For a file that is already on your disk, the round trip buys nothing."
        ]
      },
      {
        heading: "How the conversion works in this tab",
        paragraphs: [
          "Browsers can read a ZIP central directory and write binary data, so the whole job can stay local. The converter opens the archive with the same ZIP reader as the comic reader, sorts image entries naturally (2.jpg before 10.jpg), and ignores directory entries, __MACOSX folders and ComicInfo.xml.",
          "Each JPEG page is copied into the PDF as a DCT stream: the compressed image data is passed through untouched, with no decode and no re-encode. PNG pages are embedded losslessly too, including transparency. PDF has no native format for WebP, GIF, AVIF or BMP, so those pages are decoded once and written as JPEG at quality 92; that is the only path where pixels are re-compressed.",
          "Pages are processed one at a time with a pause between them, so the progress bar updates, the tab stays responsive, and Cancel is checked before every page."
        ],
        bullets: [
          "JPEG and PNG pages: embedded without re-encoding.",
          "WebP, GIF, AVIF, BMP pages: re-encoded once as JPEG at quality 92.",
          "Page order follows a natural sort of the image file names, the same order the reader uses.",
          "The finished PDF downloads directly; no link expires and no copy is kept."
        ],
        note: {
          title: "Verify it yourself",
          paragraphs: [
            "You do not have to take this on trust. Both checks take about a minute and only involve this converter."
          ],
          bullets: [
            "On a desktop, open DevTools → Network and start a conversion. The page and its scripts load, but no request carries your archive or page images; the analytics event sent during a run records only the page count, the elapsed time and the page-size choice.",
            "On a phone, open this page once while you still have a connection, then switch on airplane mode and reload it. Convert a local CBZ with no network at all: the PDF is still built and downloaded."
          ]
        }
      },
      {
        heading: "Original size or A4",
        paragraphs: [
          "With original size, one image pixel becomes one PDF point, so a 3000 × 4500 scan produces a 3000 × 4500 point page. Nothing is scaled, and viewers or printers shrink it to fit their own output. This is how most comic PDFs are built, and it preserves every pixel.",
          "With A4, every page becomes 595 × 842 points and the image is scaled to fit inside it without cropping or stretching, centred with margins. Choose this when the PDF is meant for printing or for an app that handles very large page boxes badly. The embedded image data is identical in both modes, so file size barely changes; only the page geometry does."
        ]
      },
      {
        heading: "What this converter does not do",
        bullets: [
          "No OCR and no text layer. Output pages are images, so text cannot be selected, searched or read aloud.",
          "One archive at a time. Batch conversion is not implemented.",
          "No CBR (RAR) or CB7 (7z) input. Browsers cannot open those containers; convert them to CBZ first.",
          "No password-protected archives. Encrypted pages are rejected before anything is written.",
          "No server fallback. If a very large archive exhausts the tab memory, the conversion stops with an error instead of uploading the file."
        ]
      },
      {
        heading: "When a conversion fails",
        paragraphs: [
          "Encrypted archives are rejected up front. An archive with no image entries is rejected with the number of entries that were found. A page that cannot be decoded stops the run and names the file inside the archive. Running out of memory, which usually takes hundreds of very large pages, is reported as a memory error; closing other tabs or splitting the archive is the practical fix.",
          "Cancel stops the run between pages and discards the partial PDF. Nothing is downloaded and no temporary file is left behind."
        ]
      }
    ],
    faq: [
      {
        question: "Does converting to PDF reduce image quality?",
        answer: "For JPEG and PNG pages, no. The compressed image data is copied into the PDF unchanged. WebP, GIF, AVIF and BMP pages are re-encoded once as JPEG at quality 92, because PDF has no native format for them. If your archive is made of JPEG scans, as most CBZ files are, each page image in the PDF is the same data as in the archive."
      },
      {
        question: "Can I convert several CBZ files at once?",
        answer: "No. One archive at a time keeps memory bounded and makes cancellation predictable. Start the next file after the first PDF has downloaded."
      },
      {
        question: "What happens with a password-protected archive?",
        answer: "It is rejected with an explanation. Remove the password in your archive tool, save a plain CBZ, then convert that file."
      },
      {
        question: "Which page size should I choose?",
        answer: "Use original size for an archival PDF that matches the scans exactly, and A4 when the PDF will be printed. The image data is the same in both modes, so quality and file size barely change."
      },
      {
        question: "Are my files uploaded anywhere?",
        answer: "No. The archive is read with the browser file API and the PDF is assembled in the tab. No request carries file content; the analytics events for a conversion record only the page count, the elapsed time and the page-size choice."
      },
      {
        question: "How can I check that the conversion does not upload my file?",
        answer: "Open this page once, then either watch DevTools → Network while converting or switch a phone to airplane mode and convert. On desktop the request list shows the page, its scripts and an analytics ping, but nothing that carries the archive or the page images. With the network off, the same conversion still finishes and downloads a PDF. This applies to this converter only: the archive and the finished PDF never leave the tab."
      },
      {
        question: "Does the converter work offline?",
        answer: "Yes, after the first visit. The converter ships in the same offline-capable shell as the reader, and your CBZ is a local file either way."
      }
    ],
    related: ["/", "/what-is-a-cbz-file/", "/cbz-file-format/", "/cbz-file-wont-open/"],
    bridge: {
      text: "Only want to look through the archive, not convert it?",
      href: "/",
      label: "Open this CBZ in the browser reader"
    }
  }
];
function findPage(pathname) {
  const normalized = pathname === "/" ? "/" : pathname.endsWith("/") ? pathname : `${pathname}/`;
  return PAGES.find((page) => page.path === normalized) ?? PAGES[0];
}
const year = 2026;
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "LandingPage",
  __ssrInlineRender: true,
  props: {
    page: {}
  },
  setup(__props) {
    const props = __props;
    const { t, tm, locale } = useI18n();
    const related = computed(
      () => props.page.related.map((path) => {
        const page = findPage(path);
        return { path, label: page.h1 };
      })
    );
    const isLocalized = computed(() => locale.value !== "en");
    const homeHref = computed(() => isLocalized.value ? `/${locale.value}/` : "/");
    const isHome = computed(() => ["/", "/zh/", "/ja/"].includes(props.page.path));
    const navItems = computed(
      () => NAV.map((item) => ({
        ...item,
        label: t(item.labelKey),
        href: item.href === "/" ? homeHref.value : item.href
      }))
    );
    const DEFAULT_TRUST = computed(() => tm("home.defaultTrust"));
    const trustItems = computed(() => props.page.trust ?? DEFAULT_TRUST.value);
    function toolKindLabel(kind) {
      if (kind === "sample") return t("home.kindSample");
      if (kind === "tool") return t("home.kindTool");
      return t("home.kindGuide");
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><header class="site-header"><div class="site-header__inner"><a class="brand"${ssrRenderAttr("href", homeHref.value)}><span class="brand__mark" aria-hidden="true">CBZ</span><span>${ssrInterpolate(unref(SITE).name)}</span></a><div class="site-header__actions"><nav class="site-nav"${ssrRenderAttr("aria-label", unref(t)("nav.primary"))}><!--[-->`);
      ssrRenderList(navItems.value, (item) => {
        _push(`<a${ssrRenderAttr("href", item.href)}${ssrRenderAttr("aria-current", __props.page.path === item.href ? "page" : void 0)}>${ssrInterpolate(item.label)}</a>`);
      });
      _push(`<!--]--></nav><div class="lang-switch"><select class="lang-switch__select"${ssrRenderAttr("aria-label", unref(t)("header.language"))}${ssrRenderAttr("data-en-href", isLocalized.value ? "/" : __props.page.path)} data-lang-switch><option value="en"${ssrIncludeBooleanAttr(unref(locale) === "en") ? " selected" : ""}>EN</option><option value="zh"${ssrIncludeBooleanAttr(unref(locale) === "zh") ? " selected" : ""}>中文</option><option value="ja"${ssrIncludeBooleanAttr(unref(locale) === "ja") ? " selected" : ""}>日本語</option></select></div><div class="theme-switch"><button type="button" class="theme-switch__trigger"${ssrRenderAttr("aria-label", unref(t)("header.themeDark"))} aria-pressed="false"${ssrRenderAttr("title", unref(t)("header.themeDark"))}><svg class="theme-switch__icon theme-switch__icon--sun" viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="3"></circle><path d="M8 1.5v2M8 12.5v2M1.5 8h2M12.5 8h2M3.4 3.4l1.4 1.4M11.2 11.2l1.4 1.4M12.6 3.4l-1.4 1.4M4.8 11.2l-1.4 1.4"></path></svg><svg class="theme-switch__icon theme-switch__icon--moon" viewBox="0 0 16 16" aria-hidden="true"><path d="M12.5 9.6A5.5 5.5 0 0 1 6.4 3.5a5.5 5.5 0 1 0 6.1 6.1z"></path></svg></button></div></div></div></header><main class="wrap">`);
      if (!isHome.value) {
        _push(`<nav class="crumbs"${ssrRenderAttr("aria-label", unref(t)("breadcrumb.label"))}><a${ssrRenderAttr("href", homeHref.value)}>${ssrInterpolate(unref(t)("breadcrumb.reader"))}</a><span aria-hidden="true">/</span><span>${ssrInterpolate(__props.page.eyebrow)}</span></nav>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<section class="hero">`);
      if (!isHome.value) {
        _push(`<p class="eyebrow">${ssrInterpolate(__props.page.eyebrow)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<h1>${ssrInterpolate(__props.page.h1)}</h1><p class="lead">${ssrInterpolate(__props.page.lead)}</p>`);
      if (__props.page.tool) {
        _push(`<div class="doors"><a class="door" href="#reader"><span class="door__kicker">CBZ / ZIP</span><strong>${ssrInterpolate(unref(t)("home.readInBrowser"))}</strong><span class="door__note">${ssrInterpolate(unref(t)("home.readNote"))}</span><span class="door__cta">${ssrInterpolate(unref(t)("home.pickFile"))}</span></a><a class="door" href="/cbz-to-pdf/"><span class="door__kicker">CBZ → PDF</span><strong>${ssrInterpolate(unref(t)("home.convertTitle"))}</strong><span class="door__note">${ssrInterpolate(unref(t)("home.convertNote"))}</span><span class="door__cta">${ssrInterpolate(unref(t)("home.openConverter"))}</span></a></div>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.page.tool) {
        _push(`<a class="sample-link" href="/demo/"><span class="sample-link__title">${ssrInterpolate(unref(t)("home.sampleTitle"))}</span><span class="sample-link__note">${ssrInterpolate(unref(t)("home.sampleNote"))}</span></a>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<ul class="trust"><!--[-->`);
      ssrRenderList(trustItems.value, (item) => {
        _push(`<li>${ssrInterpolate(item)}</li>`);
      });
      _push(`<!--]--></ul></section>`);
      if (__props.page.tool) {
        _push(`<section id="recent-shelf" class="shelf" hidden aria-labelledby="recent-title"><div class="shelf__head"><h2 id="recent-title">${ssrInterpolate(unref(t)("home.recentTitle"))}</h2><button type="button" class="shelf__clear" data-recent-clear>${ssrInterpolate(unref(t)("home.clearAll"))}</button></div><ul class="shelf__list" data-recent-list></ul><p class="shelf__hint" data-recent-hint hidden></p></section>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.page.tool) {
        _push(`<section id="reader" class="reader-section"${ssrRenderAttr("aria-label", unref(t)("home.readerLabel"))}><div class="reader-frame"><div id="reader-app"><div class="reader-fallback"><div class="dropzone"><p class="dropzone__kicker">CBZ / ZIP</p><h2>${ssrInterpolate(unref(t)("home.openTitle"))}</h2><p>${ssrInterpolate(unref(t)("home.openLead"))}</p><button class="btn-primary" type="button" data-open-reader>${ssrInterpolate(unref(t)("home.choose"))}</button><input type="file" hidden accept=".cbz,.zip,application/vnd.comicbook+zip,application/zip"${ssrRenderAttr("aria-label", unref(t)("home.choose"))}><p class="dropzone__fine">${ssrInterpolate(unref(t)("home.fine"))}</p></div></div></div></div><p class="reader-note">${ssrInterpolate(unref(t)("home.tip"))}</p><noscript><p class="noscript">${ssrInterpolate(unref(t)("home.noscript"))}</p></noscript></section>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.page.converter) {
        _push(`<section id="converter" class="converter-section" aria-label="CBZ to PDF converter"><div class="converter-shell"><div id="converter-app"><div class="converter-fallback"><p class="converter-kicker">CBZ → PDF</p><h2>Convert a CBZ to PDF</h2><p> Drop a .cbz file here, or choose one from your device. The archive is unpacked and the PDF is built in this tab. </p><button class="btn-primary" type="button" data-convert-open>Choose a CBZ file</button><input type="file" hidden accept=".cbz,.zip,application/vnd.comicbook+zip,application/zip" aria-label="Choose a CBZ file to convert"><p class="converter-fine"> Nothing is uploaded. JPEG pages are embedded without re-encoding. </p></div></div></div><noscript><p class="noscript"> JavaScript is required to unpack the archive and build the PDF. Everything runs in your browser; the file is never sent to a server. </p></noscript></section>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.page.sections.length) {
        _push(`<div class="content"><!--[-->`);
        ssrRenderList(__props.page.sections, (section) => {
          _push(`<section><h2>${ssrInterpolate(section.heading)}</h2><!--[-->`);
          ssrRenderList(section.paragraphs, (paragraph) => {
            _push(`<p>${ssrInterpolate(paragraph)}</p>`);
          });
          _push(`<!--]-->`);
          if (section.contact && __props.page.contact) {
            _push(`<p class="contact"><a${ssrRenderAttr("href", `mailto:${__props.page.contact}`)}>${ssrInterpolate(__props.page.contact)}</a></p>`);
          } else {
            _push(`<!---->`);
          }
          if (section.bullets) {
            _push(`<ul><!--[-->`);
            ssrRenderList(section.bullets, (bullet) => {
              _push(`<li>${ssrInterpolate(bullet)}</li>`);
            });
            _push(`<!--]--></ul>`);
          } else {
            _push(`<!---->`);
          }
          if (section.note) {
            _push(`<aside class="section-note"><h3>${ssrInterpolate(section.note.title)}</h3><!--[-->`);
            ssrRenderList(section.note.paragraphs, (paragraph) => {
              _push(`<p>${ssrInterpolate(paragraph)}</p>`);
            });
            _push(`<!--]-->`);
            if (section.note.bullets) {
              _push(`<ul><!--[-->`);
              ssrRenderList(section.note.bullets, (bullet) => {
                _push(`<li>${ssrInterpolate(bullet)}</li>`);
              });
              _push(`<!--]--></ul>`);
            } else {
              _push(`<!---->`);
            }
            _push(`</aside>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</section>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.page.tools) {
        _push(`<section class="tools" aria-labelledby="tools-heading"><h2 id="tools-heading">${ssrInterpolate(unref(t)("home.toolsHeading"))}</h2><p class="tools__intro">${ssrInterpolate(unref(t)("home.toolsIntro"))}</p><div class="tools__grid"><!--[-->`);
        ssrRenderList(__props.page.tools, (tool) => {
          _push(`<a class="tool-card"${ssrRenderAttr("href", tool.href)}><span class="tool-card__kind">${ssrInterpolate(toolKindLabel(tool.kind))}</span><span class="tool-card__label">${ssrInterpolate(tool.label)}</span><span class="tool-card__note">${ssrInterpolate(tool.note)}</span></a>`);
        });
        _push(`<!--]--></div></section>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.page.bridge) {
        _push(`<p class="bridge"><span>${ssrInterpolate(__props.page.bridge.text)}</span><a${ssrRenderAttr("href", __props.page.bridge.href)}>${ssrInterpolate(__props.page.bridge.label)}</a></p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<section class="faq" aria-labelledby="faq-heading"><h2 id="faq-heading">${ssrInterpolate(unref(t)("home.questions"))}</h2><!--[-->`);
      ssrRenderList(__props.page.faq, (item) => {
        _push(`<details><summary>${ssrInterpolate(item.question)}</summary><p>${ssrInterpolate(item.answer)}</p></details>`);
      });
      _push(`<!--]--></section>`);
      if (!__props.page.tool) {
        _push(`<section class="cta"><div><h2>${ssrInterpolate(unref(t)("home.ctaTitle"))}</h2><p>${ssrInterpolate(unref(t)("home.ctaLead"))}</p></div><a class="btn-primary"${ssrRenderAttr("href", homeHref.value)}>${ssrInterpolate(unref(t)("home.ctaButton"))}</a></section>`);
      } else {
        _push(`<!---->`);
      }
      if (related.value.length) {
        _push(`<section class="related" aria-labelledby="related-heading"><h2 id="related-heading">${ssrInterpolate(unref(t)("home.related"))}</h2><div class="related__grid"><!--[-->`);
        ssrRenderList(related.value, (item) => {
          _push(`<a${ssrRenderAttr("href", item.path)}><span>${ssrInterpolate(item.label)}</span></a>`);
        });
        _push(`<!--]--></div></section>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</main><footer class="site-footer"><div class="site-footer__inner"><span>© ${ssrInterpolate(year)} ${ssrInterpolate(unref(SITE).name)}. ${ssrInterpolate(unref(t)("footer.tagline"))}</span><nav${ssrRenderAttr("aria-label", unref(t)("footer.label"))}><a${ssrRenderAttr("href", homeHref.value)}>${ssrInterpolate(unref(t)("nav.reader"))}</a><a href="/cbz-to-pdf/">${ssrInterpolate(unref(t)("nav.cbzToPdf"))}</a><a href="/how-to-open-cbz/">${ssrInterpolate(unref(t)("nav.howToOpen"))}</a><a href="/manga-reader/">${ssrInterpolate(unref(t)("nav.mangaMode"))}</a><a href="/cbz-vs-cbr/">${ssrInterpolate(unref(t)("nav.compare"))}</a><a href="/privacy/">${ssrInterpolate(unref(t)("footer.privacy"))}</a><a href="/terms/">${ssrInterpolate(unref(t)("footer.terms"))}</a><a href="/disclaimer/">${ssrInterpolate(unref(t)("footer.disclaimer"))}</a></nav></div></footer><!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/LandingPage.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const en = {
  nav: {
    primary: "Primary",
    reader: "Reader",
    cbzToPdf: "CBZ to PDF",
    howToOpen: "How to open CBZ",
    mangaMode: "Manga mode",
    compare: "CBZ vs CBR"
  },
  header: {
    language: "Language",
    themeDark: "Switch to dark theme",
    themeLight: "Switch to light theme"
  },
  footer: {
    tagline: "Files stay on your device.",
    label: "Footer",
    privacy: "Privacy",
    terms: "Terms",
    disclaimer: "Disclaimer"
  },
  breadcrumb: {
    label: "Breadcrumb",
    reader: "Reader"
  },
  home: {
    readInBrowser: "Read in the browser",
    readNote: "Open the archive and turn pages right away. Nothing is uploaded.",
    pickFile: "Pick a file",
    convertTitle: "Convert to PDF",
    convertNote: "Rebuild the same archive as a PDF, with original sizes or A4 pages.",
    openConverter: "Open the converter",
    sampleTitle: "Try with a sample comic",
    sampleNote: "Open a short public-domain comic — no file needed.",
    recentTitle: "Recently opened",
    clearAll: "Clear all",
    readerLabel: "CBZ reader",
    openTitle: "Open a CBZ file",
    openLead: "Drop a .cbz file here, or choose one from your device. The archive is read locally.",
    choose: "Choose a CBZ file",
    fine: "Nothing is uploaded. Works with CBZ and ZIP archives.",
    tip: "Tip: on iPhone or iPad, open this page first, then pick the file from the Files app. iOS does not let websites register as file handlers.",
    noscript: "JavaScript is required to unpack and display CBZ pages. The parsing runs entirely in your browser; nothing is sent to a server.",
    toolsHeading: "More CBZ tools",
    toolsIntro: "Convert an archive, look up a format detail, or fix a file that will not open.",
    kindSample: "Sample",
    kindTool: "Tool",
    kindGuide: "Guide",
    questions: "Questions",
    ctaTitle: "Read a CBZ right now",
    ctaLead: "Drop a file into the reader. It stays on your device.",
    ctaButton: "Open the CBZ reader",
    related: "Keep reading",
    defaultTrust: ["No upload", "No account", "Right-to-left ready", "Remembers your page"]
  },
  shelf: {
    modeSingle: "Single page",
    modeDouble: "Two pages",
    modeScroll: "Continuous",
    justNow: "just now",
    minutesAgo: "{count} min ago",
    hoursAgo: "{count} h ago",
    daysAgo: "{count} d ago",
    meta: "{pages} pages · {mode} · page {page}",
    wrongFile: "That was “{picked}”. Pick “{expected}” again to return to page {page}.",
    tooLarge: "This file is too large to keep a copy (or its copy was cleared). Pick “{name}” again and reading resumes at page {page}.",
    remove: "Remove {name} from recently opened",
    clearConfirm: "Remove every recent file, stored copy and bookmark?"
  },
  reader: {
    kicker: "CBZ / ZIP",
    readingArchive: "Reading archive...",
    openTitle: "Open a CBZ file",
    buildingList: "Building the page list and decoding the first page.",
    openLead: "Drop a .cbz file here, or choose one from your device. Pages are unpacked locally.",
    opening: "Opening...",
    chooseFile: "Choose a CBZ file",
    fine: "Nothing is uploaded. Works with CBZ and ZIP archives.",
    modeSingle: "Single",
    modeDouble: "Double",
    modeScroll: "Scroll",
    modeTitle: "Reading mode: {mode} — tap to switch",
    modeAria: "Reading mode: {mode}. Switch to the next mode.",
    zoomTitle: "Zoom {level}% — click to fit width",
    zoomAria: "Zoom {level}%, reset to fit width",
    bookmarkAdd: "Bookmark this page",
    bookmarkRemove: "Remove bookmark from this page",
    rtlTitle: "Reading direction: right to left — switch to left to right",
    ltrTitle: "Reading direction: left to right — switch to right to left",
    rtlAria: "Reading direction: right to left. Switch to left to right.",
    ltrAria: "Reading direction: left to right. Switch to right to left.",
    openAnother: "Open another CBZ file",
    moreOptions: "More options",
    moreOptionsAria: "More reading options",
    optionsLabel: "Reading options",
    rtlOption: "Right-to-left reading",
    on: "On",
    off: "Off",
    showBrowser: "Show browser interface (F)",
    hideBrowser: "Hide browser interface (F)",
    bookmarkRemoveShort: "Remove bookmark",
    theme: "Theme",
    darkMode: "Dark mode",
    bookmarks: "Bookmarks",
    pageNumber: "Page {page}",
    here: "Here",
    removeBookmarkPage: "Remove bookmark on page {page}",
    comicInfo: "Comic info",
    close: "Close reader",
    iosHint: "Add to Home Screen to read without Safari's bars.",
    dismiss: "Dismiss",
    dismissHint: "Dismiss hint",
    comicPages: "Comic pages",
    retry: "Retry",
    dropToOpen: "Drop to open",
    resumed: "Resumed at page {page}",
    startOver: "Start over",
    prev: "Prev",
    next: "Next",
    page: "Page",
    thumbnails: "Page thumbnails",
    pages: "Pages",
    pageCount: "{count} pages",
    contents: "Contents",
    goToPage: "Go to page {page}",
    singlePage: "Page {page} / {total}",
    doublePage: "Page {page} / {total}",
    doublePages: "Pages {start}-{end} / {total}",
    genericError: "Something went wrong while opening this file."
  },
  errors: {
    unsupportedCbr: "CBR (RAR) archives are not supported yet. Convert the file to CBZ first: extract the page images, then re-zip them as a .cbz file. Renaming a .cbr to .cbz is not enough, because the container inside is still RAR.",
    unsupportedCb7: "CB7 (7z) archives are not supported yet. Convert the file to CBZ first: extract the page images and re-pack them as a .cbz file, then open that archive instead.",
    notZip: "This file could not be read as a CBZ or ZIP archive. If it came from a CBR (RAR) or CB7 (7z) file, convert it to CBZ first and try again.",
    encrypted: "This archive is password-protected. Remove the password and try again.",
    noImages: "No readable images were found in this archive.",
    missingPage: "That page is not in this archive.",
    decode: "This page could not be decoded.",
    topLevel: "Top level"
  }
};
const zhHome = {
  path: "/zh/",
  title: "CBZ Reader - 在浏览器里读 CBZ、转 PDF",
  description: "在浏览器中阅读 CBZ 漫画，或把 CBZ 转成 PDF。文件始终留在本机：无需上传、无需账号。支持日漫右开、双页、缩放和阅读进度。",
  h1: "在浏览器里读 CBZ 漫画",
  eyebrow: "CBZ 阅读器与转换工具",
  lead: "打开 CBZ 直接读，或转成 PDF。两件事都在你的设备上完成。",
  tool: true,
  schema: "app",
  schemaFeatures: [
    "在本地打开 CBZ 和 ZIP 漫画压缩包",
    "在浏览器里把 CBZ 转成 PDF，不上传文件",
    "从右到左的日漫阅读模式",
    "单页与双页排版",
    "缩放与拖动",
    "在本机保存阅读进度"
  ],
  updated: "2026-11-12",
  trust: ["文件不会上传，始终留在浏览器里，也不需要账号。"],
  sections: [],
  faq: [
    {
      question: "漫画会被上传到服务器吗？",
      answer: "不会。文件通过浏览器的文件选择器打开，并在页面里解析，页面图片也在本地解码。文件不会发到这个网站，也不会发给第三方。"
    },
    {
      question: "第一次访问之后，离线还能用吗？",
      answer: "可以。页面外壳由 Service Worker 缓存，所以断网后也能重新打开阅读器；CBZ 从你的设备读取，翻页不需要网络。没有在这个站点打开过的页面不会被保存，浏览器也可能在长期不访问后清掉缓存，联网访问一次即可恢复。"
    },
    {
      question: "支持哪些格式？",
      answer: "支持包含 JPG、PNG、WebP、GIF、AVIF 或 BMP 页面的 CBZ 和 ZIP 压缩包。CBR 和 CB7 已在计划中，但当前版本还不支持。"
    }
  ],
  tools: [
    {
      href: "/cbz-to-pdf/",
      label: "CBZ 转 PDF",
      note: "按原始尺寸或 A4 输出。",
      kind: "tool"
    },
    {
      href: "/read-cbz-online/",
      label: "在线读 CBZ",
      note: "不上传文件时，流程有什么不同。",
      kind: "guide"
    },
    {
      href: "/manga-reader/",
      label: "漫画模式",
      note: "一键切换右开双页。",
      kind: "guide"
    },
    {
      href: "/how-to-open-cbz/",
      label: "如何打开 CBZ",
      note: "电脑、Android、iPhone。",
      kind: "guide"
    },
    {
      href: "/what-is-a-cbz-file/",
      label: "CBZ 是什么文件？",
      note: "ZIP 容器、页面和元数据。",
      kind: "guide"
    },
    {
      href: "/cbz-file-format/",
      label: "CBZ 格式详解",
      note: "ComicInfo.xml、页序和排版。",
      kind: "guide"
    },
    {
      href: "/how-to-make-a-cbz-file/",
      label: "制作 CBZ",
      note: "把扫描图打包成可读的压缩包。",
      kind: "guide"
    },
    {
      href: "/cbz-file-wont-open/",
      label: "CBZ 打不开怎么办",
      note: "扩展名被改过的 RAR，或加密文件。",
      kind: "guide"
    },
    {
      href: "/cbz-vs-cbr/",
      label: "CBZ、CBR 与 CB7",
      note: "浏览器能打开哪些容器。",
      kind: "guide"
    },
    {
      href: "/read-cbz-on-iphone/",
      label: "在 iPhone 上读 CBZ",
      note: "「文件」App 与 Safari 的限制。",
      kind: "guide"
    },
    {
      href: "/read-cbz-on-android/",
      label: "在 Android 上读 CBZ",
      note: "从下载目录或 Drive 打开，不用装 App。",
      kind: "guide"
    },
    {
      href: "/demo/",
      label: "试读样例漫画",
      note: "一部公版作品，无需准备文件。",
      kind: "sample"
    }
  ],
  related: []
};
const zh = {
  nav: {
    primary: "主导航",
    reader: "阅读器",
    cbzToPdf: "CBZ 转 PDF",
    howToOpen: "如何打开 CBZ",
    mangaMode: "漫画模式",
    compare: "CBZ 与 CBR"
  },
  header: {
    language: "语言",
    themeDark: "切换到深色主题",
    themeLight: "切换到浅色主题"
  },
  footer: {
    tagline: "文件只留在你的设备上。",
    label: "页脚导航",
    privacy: "隐私政策",
    terms: "使用条款",
    disclaimer: "免责声明"
  },
  breadcrumb: {
    label: "面包屑导航",
    reader: "阅读器"
  },
  home: {
    readInBrowser: "在浏览器里阅读",
    readNote: "打开压缩包就能翻页，文件不会上传。",
    pickFile: "选择文件",
    convertTitle: "转成 PDF",
    convertNote: "按原始尺寸或 A4 重新生成 PDF，内容仍在本机处理。",
    openConverter: "打开转换工具",
    sampleTitle: "用样例漫画试一下",
    sampleNote: "直接打开一部公版短篇，不需要准备文件。",
    recentTitle: "最近打开",
    clearAll: "全部清除",
    readerLabel: "CBZ 阅读器",
    openTitle: "打开 CBZ 文件",
    openLead: "把 .cbz 文件拖到这里，或从设备中选择。压缩包只在本地读取。",
    choose: "选择 CBZ 文件",
    fine: "不会上传。支持 CBZ 和 ZIP 压缩包。",
    tip: "小提示：在 iPhone 或 iPad 上，先打开本页，再从「文件」App 里选择文件。iOS 不允许网站注册为文件处理器。",
    noscript: "解压和显示 CBZ 页面需要 JavaScript。所有解析都在浏览器里完成，不会发送到服务器。",
    toolsHeading: "更多 CBZ 工具",
    toolsIntro: "转换压缩包、查格式细节，或处理打不开的文件。",
    kindSample: "样例",
    kindTool: "工具",
    kindGuide: "指南",
    questions: "常见问题",
    ctaTitle: "现在就打开一本 CBZ",
    ctaLead: "把文件拖进阅读器，它不会离开你的设备。",
    ctaButton: "打开 CBZ 阅读器",
    related: "继续阅读",
    defaultTrust: ["不上传", "无需账号", "支持右开", "记住进度"]
  },
  shelf: {
    modeSingle: "单页",
    modeDouble: "双页",
    modeScroll: "连续",
    justNow: "刚刚",
    minutesAgo: "{count} 分钟前",
    hoursAgo: "{count} 小时前",
    daysAgo: "{count} 天前",
    meta: "{pages} 页 · {mode} · 第 {page} 页",
    wrongFile: "刚才选的是「{picked}」。要回到第 {page} 页，请重新选择「{expected}」。",
    tooLarge: "这个文件太大，无法保留副本（或副本已被清理）。重新选择「{name}」后会从第 {page} 页继续。",
    remove: "从最近打开中移除 {name}",
    clearConfirm: "要移除所有最近文件、本地副本和书签吗？"
  },
  reader: {
    kicker: "CBZ / ZIP",
    readingArchive: "正在读取压缩包…",
    openTitle: "打开 CBZ 文件",
    buildingList: "正在整理页序并解码第一页。",
    openLead: "把 .cbz 文件拖到这里，或从设备中选择。页面只在本地解压。",
    opening: "正在打开…",
    chooseFile: "选择 CBZ 文件",
    fine: "不会上传。支持 CBZ 和 ZIP 压缩包。",
    modeSingle: "单页",
    modeDouble: "双页",
    modeScroll: "连续",
    modeTitle: "阅读模式：{mode}，点击切换",
    modeAria: "当前阅读模式：{mode}。切换到下一模式。",
    zoomTitle: "缩放 {level}%，点击适应宽度",
    zoomAria: "当前缩放 {level}%，重置为适应宽度",
    bookmarkAdd: "给本页加书签",
    bookmarkRemove: "移除本页书签",
    rtlTitle: "阅读方向：从右到左，点击改为从左到右",
    ltrTitle: "阅读方向：从左到右，点击改为从右到左",
    rtlAria: "当前从右到左阅读。改为从左到右。",
    ltrAria: "当前从左到右阅读。改为从右到左。",
    openAnother: "打开另一个 CBZ 文件",
    moreOptions: "更多选项",
    moreOptionsAria: "更多阅读选项",
    optionsLabel: "阅读选项",
    rtlOption: "从右到左阅读",
    on: "开",
    off: "关",
    showBrowser: "显示浏览器界面（F）",
    hideBrowser: "隐藏浏览器界面（F）",
    bookmarkRemoveShort: "移除书签",
    theme: "主题",
    darkMode: "深色模式",
    bookmarks: "书签",
    pageNumber: "第 {page} 页",
    here: "当前",
    removeBookmarkPage: "移除第 {page} 页的书签",
    comicInfo: "漫画信息",
    close: "关闭阅读器",
    iosHint: "添加到主屏幕后，阅读时可以隐藏 Safari 的工具栏。",
    dismiss: "知道了",
    dismissHint: "关闭提示",
    comicPages: "漫画页面",
    retry: "重试",
    dropToOpen: "松开以打开",
    resumed: "已从第 {page} 页继续",
    startOver: "从头开始",
    prev: "上一页",
    next: "下一页",
    page: "页码",
    thumbnails: "页面缩略图",
    pages: "页面",
    pageCount: "{count} 页",
    contents: "目录",
    goToPage: "跳到第 {page} 页",
    singlePage: "第 {page} 页 / 共 {total} 页",
    doublePage: "第 {page} 页 / 共 {total} 页",
    doublePages: "第 {start}-{end} 页 / 共 {total} 页",
    genericError: "打开这个文件时出了点问题。"
  },
  errors: {
    unsupportedCbr: "暂不支持 CBR（RAR）压缩包。请先转成 CBZ：解压出页面图片，再重新打包为 .cbz 文件。只把 .cbr 改名成 .cbz 不够，里面的容器仍然是 RAR。",
    unsupportedCb7: "暂不支持 CB7（7z）压缩包。请先转成 CBZ：解压出页面图片，重新打包为 .cbz 文件，再打开新的压缩包。",
    notZip: "这个文件无法按 CBZ 或 ZIP 压缩包读取。如果它来自 CBR（RAR）或 CB7（7z），请先转成 CBZ 再试。",
    encrypted: "这个压缩包有密码保护。请先去掉密码再打开。",
    noImages: "这个压缩包里没有可读取的图片。",
    missingPage: "这个压缩包里没有这一页。",
    decode: "这一页无法解码。",
    topLevel: "最上层"
  }
};
const jaHome = {
  path: "/ja/",
  title: "CBZ Reader - ブラウザでCBZを読む・PDFに変換",
  description: "ブラウザ上でCBZコミックを読み、CBZをPDFに変換できます。ファイルは端末内だけで処理され、アップロードもアカウント登録も不要です。右開きのマンガ、見開き、ズーム、続きからの再開に対応。",
  h1: "ブラウザでCBZコミックを読む",
  eyebrow: "CBZリーダーと変換ツール",
  lead: "CBZを開いてそのまま読むか、PDFに変換できます。どちらも端末内で完結します。",
  tool: true,
  schema: "app",
  schemaFeatures: [
    "CBZとZIPのコミックアーカイブをローカルで開く",
    "アップロードせずにブラウザでCBZをPDFに変換",
    "右から左に読むマンガモード",
    "単ページと見開きのレイアウト",
    "ズームとパン",
    "端末内に閲覧位置を保存"
  ],
  updated: "2026-11-12",
  trust: ["ファイルはアップロードされず、ブラウザ内だけで処理されます。アカウントも不要です。"],
  sections: [],
  faq: [
    {
      question: "コミックはサーバーにアップロードされますか？",
      answer: "いいえ。ファイルはブラウザのファイル選択から開き、ページ内で解析されます。ページ画像も端末内でデコードされ、当サイトや第三者に送信されることはありません。"
    },
    {
      question: "初回アクセス後はオフラインでも使えますか？",
      answer: "はい。ページの外枠はService Workerがキャッシュするため、接続がなくてもリーダーを開き直せます。CBZは端末から読み込むので、ページ送りにもネットワークは不要です。当サイトで一度も開いていないページは保存されず、長期間アクセスがないとブラウザがキャッシュを削除することがあります。オンラインで一度開けば復元されます。"
    },
    {
      question: "対応している形式は？",
      answer: "JPG、PNG、WebP、GIF、AVIF、BMPのページを含むCBZとZIPに対応しています。CBRとCB7は計画中で、現在のバージョンでは未対応です。"
    }
  ],
  tools: [
    {
      href: "/cbz-to-pdf/",
      label: "CBZをPDFに変換",
      note: "元のサイズ、またはA4で出力。",
      kind: "tool"
    },
    {
      href: "/read-cbz-online/",
      label: "CBZをオンラインで読む",
      note: "アップロードしない場合との違い。",
      kind: "guide"
    },
    {
      href: "/manga-reader/",
      label: "マンガモード",
      note: "右開きの見開きをワンタップで。",
      kind: "guide"
    },
    {
      href: "/how-to-open-cbz/",
      label: "CBZの開き方",
      note: "パソコン、Android、iPhone。",
      kind: "guide"
    },
    {
      href: "/what-is-a-cbz-file/",
      label: "CBZファイルとは",
      note: "ZIPコンテナ、ページ、メタデータ。",
      kind: "guide"
    },
    {
      href: "/cbz-file-format/",
      label: "CBZ形式の内部",
      note: "ComicInfo.xml、ページ順、レイアウト。",
      kind: "guide"
    },
    {
      href: "/how-to-make-a-cbz-file/",
      label: "CBZを作る",
      note: "スキャン画像を読めるアーカイブに。",
      kind: "guide"
    },
    {
      href: "/cbz-file-wont-open/",
      label: "CBZが開けないとき",
      note: "拡張子だけ変えたRARや暗号化。",
      kind: "guide"
    },
    {
      href: "/cbz-vs-cbr/",
      label: "CBZ・CBR・CB7の違い",
      note: "ブラウザで開けるコンテナ。",
      kind: "guide"
    },
    {
      href: "/read-cbz-on-iphone/",
      label: "iPhoneでCBZを読む",
      note: "ファイルAppとSafariの制限。",
      kind: "guide"
    },
    {
      href: "/read-cbz-on-android/",
      label: "AndroidでCBZを読む",
      note: "ダウンロードやDriveからアプリなしで。",
      kind: "guide"
    },
    {
      href: "/demo/",
      label: "サンプルコミックを試す",
      note: "パブリックドメイン作品をファイルなしで。",
      kind: "sample"
    }
  ],
  related: []
};
const ja = {
  nav: {
    primary: "メインナビゲーション",
    reader: "リーダー",
    cbzToPdf: "CBZをPDFに",
    howToOpen: "CBZの開き方",
    mangaMode: "マンガモード",
    compare: "CBZとCBR"
  },
  header: {
    language: "言語",
    themeDark: "ダークテーマに切り替える",
    themeLight: "ライトテーマに切り替える"
  },
  footer: {
    tagline: "ファイルは端末内に残ります。",
    label: "フッターナビゲーション",
    privacy: "プライバシー",
    terms: "利用規約",
    disclaimer: "免責事項"
  },
  breadcrumb: {
    label: "パンくずリスト",
    reader: "リーダー"
  },
  home: {
    readInBrowser: "ブラウザで読む",
    readNote: "アーカイブを開けばすぐにページをめくれます。アップロードはありません。",
    pickFile: "ファイルを選ぶ",
    convertTitle: "PDFに変換",
    convertNote: "同じアーカイブを元のサイズ、またはA4のPDFにします。",
    openConverter: "変換ツールを開く",
    sampleTitle: "サンプルコミックで試す",
    sampleNote: "短いパブリックドメイン作品を、ファイルなしで開けます。",
    recentTitle: "最近開いたファイル",
    clearAll: "すべて削除",
    readerLabel: "CBZリーダー",
    openTitle: "CBZファイルを開く",
    openLead: ".cbzファイルをここにドロップするか、端末から選択してください。アーカイブはローカルで読み込まれます。",
    choose: "CBZファイルを選ぶ",
    fine: "アップロードはありません。CBZとZIPに対応しています。",
    tip: "ヒント：iPhoneやiPadでは、先にこのページを開いてから「ファイル」Appで選択してください。iOSではWebサイトをファイルハンドラとして登録できません。",
    noscript: "CBZの展開と表示にはJavaScriptが必要です。処理はすべてブラウザ内で行われ、サーバーには送信されません。",
    toolsHeading: "その他のCBZツール",
    toolsIntro: "アーカイブの変換、形式の確認、開けないファイルの対処に使えます。",
    kindSample: "サンプル",
    kindTool: "ツール",
    kindGuide: "ガイド",
    questions: "よくある質問",
    ctaTitle: "今すぐCBZを読む",
    ctaLead: "ファイルをリーダーにドロップしてください。端末の外には出ません。",
    ctaButton: "CBZリーダーを開く",
    related: "続けて読む",
    defaultTrust: ["アップロードなし", "アカウント不要", "右開き対応", "続きから再開"]
  },
  shelf: {
    modeSingle: "単ページ",
    // TODO(ja-review): confirm the UI label for a two-page spread.
    modeDouble: "見開き",
    modeScroll: "縦スクロール",
    justNow: "たった今",
    minutesAgo: "{count}分前",
    hoursAgo: "{count}時間前",
    daysAgo: "{count}日前",
    meta: "{pages}ページ · {mode} · {page}ページ目",
    wrongFile: "選択したのは「{picked}」です。{page}ページ目に戻るには「{expected}」をもう一度選んでください。",
    tooLarge: "このファイルは大きすぎてコピーを保存できません（またはコピーが削除されました）。「{name}」をもう一度選ぶと{page}ページ目から再開します。",
    remove: "最近開いたファイルから{name}を削除",
    clearConfirm: "最近のファイル、保存したコピー、しおりをすべて削除しますか？"
  },
  reader: {
    kicker: "CBZ / ZIP",
    readingArchive: "アーカイブを読み込み中…",
    openTitle: "CBZファイルを開く",
    buildingList: "ページ順を整理し、1ページ目をデコードしています。",
    openLead: ".cbzファイルをここにドロップするか、端末から選択してください。ページはローカルで展開されます。",
    opening: "開いています…",
    chooseFile: "CBZファイルを選ぶ",
    fine: "アップロードはありません。CBZとZIPに対応しています。",
    modeSingle: "単ページ",
    modeDouble: "見開き",
    modeScroll: "縦スクロール",
    modeTitle: "閲覧モード：{mode}（タップで切り替え）",
    modeAria: "現在の閲覧モード：{mode}。次のモードに切り替えます。",
    zoomTitle: "ズーム {level}%（クリックで幅に合わせる）",
    zoomAria: "現在のズーム {level}%。幅に合わせてリセットします。",
    // TODO(ja-review): confirm that しおり is the preferred term for page bookmarks.
    bookmarkAdd: "このページにしおりを追加",
    bookmarkRemove: "このページのしおりを削除",
    rtlTitle: "閲覧方向：右から左（クリックで左から右に変更）",
    ltrTitle: "閲覧方向：左から右（クリックで右から左に変更）",
    rtlAria: "現在は右から左に読んでいます。左から右に変更します。",
    ltrAria: "現在は左から右に読んでいます。右から左に変更します。",
    openAnother: "別のCBZファイルを開く",
    moreOptions: "その他のオプション",
    moreOptionsAria: "その他の閲覧オプション",
    optionsLabel: "閲覧オプション",
    rtlOption: "右から左に読む",
    on: "オン",
    off: "オフ",
    showBrowser: "ブラウザの表示を出す（F）",
    hideBrowser: "ブラウザの表示を隠す（F）",
    bookmarkRemoveShort: "しおりを削除",
    theme: "テーマ",
    darkMode: "ダークモード",
    bookmarks: "しおり",
    pageNumber: "{page}ページ",
    here: "現在",
    removeBookmarkPage: "{page}ページのしおりを削除",
    comicInfo: "コミック情報",
    close: "リーダーを閉じる",
    iosHint: "ホーム画面に追加すると、Safariのバーを隠して読めます。",
    dismiss: "閉じる",
    dismissHint: "ヒントを閉じる",
    // TODO(ja-review): natural label for the comic page-list region.
    comicPages: "コミックのページ",
    retry: "再試行",
    dropToOpen: "ドロップして開く",
    resumed: "{page}ページ目から再開しました",
    startOver: "最初から",
    prev: "前へ",
    next: "次へ",
    page: "ページ番号",
    thumbnails: "ページのサムネイル",
    pages: "ページ",
    pageCount: "{count}ページ",
    contents: "目次",
    goToPage: "{page}ページへ移動",
    singlePage: "{page} / {total}ページ",
    doublePage: "{page} / {total}ページ",
    doublePages: "{start}-{end} / {total}ページ",
    genericError: "ファイルを開くときに問題が発生しました。"
  },
  errors: {
    unsupportedCbr: "CBR（RAR）アーカイブはまだ対応していません。先にCBZへ変換してください。ページ画像を取り出して、.cbzとして再圧縮します。拡張子だけを.cbrから.cbzに変えても、中身はRARのままなので開けません。",
    unsupportedCb7: "CB7（7z）アーカイブはまだ対応していません。先にCBZへ変換してください。ページ画像を取り出して.cbzとして再圧縮し、そのアーカイブを開いてください。",
    notZip: "このファイルはCBZまたはZIPとして読み込めませんでした。CBR（RAR）やCB7（7z）から来た場合は、先にCBZへ変換してからもう一度お試しください。",
    encrypted: "このアーカイブはパスワードで保護されています。パスワードを解除してからもう一度お試しください。",
    noImages: "このアーカイブには読み込める画像がありません。",
    missingPage: "このアーカイブにそのページはありません。",
    decode: "このページをデコードできませんでした。",
    // TODO(ja-review): confirm the label for the root folder group.
    topLevel: "最上位"
  }
};
const messages = { en, zh, ja };
const LOCALIZED_HOME_PAGES = {
  zh: zhHome,
  ja: jaHome
};
const HOME_ALTERNATES = [
  { hreflang: "en", path: "/" },
  { hreflang: "zh", path: "/zh/" },
  { hreflang: "ja", path: "/ja/" },
  { hreflang: "x-default", path: "/" }
];
function htmlLang(locale) {
  if (locale === "zh") return "zh-CN";
  if (locale === "ja") return "ja";
  return "en";
}
function isLocalizedHomePath(pathname) {
  return pathname === "/zh/" || pathname === "/ja/";
}
function createSiteI18n(locale) {
  return createI18n({
    legacy: false,
    locale,
    fallbackLocale: "en",
    messages
  });
}
let currentLocale = "en";
createI18n({
  legacy: false,
  locale: currentLocale,
  fallbackLocale: "en",
  messages
});
const THEME_KEY = "cbz-theme";
const THEME_COLORS = {
  light: "#f7f5f0",
  dark: "#0d0d12"
};
ref("auto");
ref("light");
function themeScript() {
  return `<script>(function(){var d;try{var s=localStorage.getItem("${THEME_KEY}");if(s==="light"||s==="dark")d=s}catch(e){}if(!d){d=window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}var r=document.documentElement;r.setAttribute("data-theme",d);r.style.colorScheme=d;var m=document.querySelector('meta[name="theme-color"]');if(m)m.setAttribute("content",d==="dark"?"${THEME_COLORS.dark}":"${THEME_COLORS.light}")})()<\/script>`;
}
function escapeHtml(value) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function scriptJson(data) {
  const json = JSON.stringify(data).replace(/</g, "\\u003c");
  return `<script type="application/ld+json">${json}<\/script>`;
}
function absolute(siteUrl2, path) {
  return `${siteUrl2.replace(/\/$/, "")}${path}`;
}
function buildSchema(page, url, siteUrl2, locale, isHome) {
  const language = htmlLang(locale);
  const organizationId = `${siteUrl2}/#organization`;
  const graph = [
    {
      "@type": "Organization",
      "@id": organizationId,
      name: SITE.name,
      url: `${siteUrl2}/`
    },
    {
      "@type": "WebSite",
      "@id": `${siteUrl2}/#website`,
      url: `${siteUrl2}/`,
      name: SITE.name,
      description: SITE.description,
      inLanguage: language,
      publisher: { "@id": organizationId }
    }
  ];
  if (page.schema === "app") {
    graph.push({
      "@type": "WebApplication",
      "@id": `${url}#app`,
      name: SITE.name,
      url,
      description: page.description,
      applicationCategory: "MultimediaApplication",
      operatingSystem: "Any (web browser)",
      browserRequirements: "Requires JavaScript",
      inLanguage: language,
      isAccessibleForFree: true,
      offers: {
        "@type": "Offer",
        price: "0",
        priceCurrency: "USD"
      },
      featureList: page.schemaFeatures ?? [
        "Open CBZ and ZIP comic archives locally",
        "Right-to-left manga reading mode",
        "Single-page and double-page layouts",
        "Zoom and pan",
        "Local reading progress"
      ],
      publisher: { "@id": organizationId }
    });
  } else if (!page.legal) {
    graph.push({
      "@type": "Article",
      "@id": `${url}#article`,
      headline: page.h1,
      description: page.description,
      url,
      mainEntityOfPage: url,
      datePublished: page.updated,
      dateModified: page.updated,
      inLanguage: language,
      author: { "@id": organizationId },
      publisher: { "@id": organizationId }
    });
  }
  if (page.faq.length > 0) {
    graph.push({
      "@type": "FAQPage",
      "@id": `${url}#faq`,
      mainEntity: page.faq.map((item) => ({
        "@type": "Question",
        name: item.question,
        acceptedAnswer: { "@type": "Answer", text: item.answer }
      }))
    });
  }
  if (!isHome) {
    graph.push({
      "@type": "BreadcrumbList",
      "@id": `${url}#breadcrumb`,
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "CBZ Reader", item: `${siteUrl2}/` },
        { "@type": "ListItem", position: 2, name: page.h1, item: url }
      ]
    });
  }
  return { "@context": "https://schema.org", "@graph": graph };
}
const ANALYTICS = '<script defer src="https://cloud.umami.is/script.js" data-website-id="3f17a819-f15d-4d7f-8143-ed16f426b12e"><\/script>';
const BAIDU_VERIFY = '<meta name="baidu-site-verification" content="codeva-onRzaCKsaC" />';
const OG_LOCALES = {
  en: "en_US",
  zh: "zh_CN",
  ja: "ja_JP"
};
function renderHead(page, siteUrl2, options = {}) {
  const locale = options.locale ?? "en";
  const isHome = page.path === "/" || isLocalizedHomePath(page.path);
  const alternates = options.alternates ?? [
    { hreflang: "en", path: page.path },
    { hreflang: "x-default", path: page.path }
  ];
  const url = absolute(siteUrl2, page.path);
  const title = escapeHtml(page.title);
  const description = escapeHtml(page.description);
  const ogType = page.schema === "app" ? "website" : "article";
  const ogImage = `${siteUrl2.replace(/\/$/, "")}/og-image.png`;
  const schema = scriptJson(buildSchema(page, url, siteUrl2, locale, isHome));
  const alternateLinks = alternates.map(
    (alternate) => `<link rel="alternate" hreflang="${alternate.hreflang}" href="${absolute(siteUrl2, alternate.path)}" />`
  ).join("\n");
  return `<title>${title}</title>
<meta name="description" content="${description}" />
<link rel="canonical" href="${url}" />
${alternateLinks}
<meta name="robots" content="index,follow,max-image-preview:large" />
${page.path === "/" ? BAIDU_VERIFY + "\n" : ""}
<meta name="theme-color" content="${THEME_COLORS.light}" />
${themeScript()}
<link rel="manifest" href="/manifest.webmanifest" />
<link rel="manifest" href="/manifest-dark.webmanifest" media="(prefers-color-scheme: dark)" />
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
<meta property="og:type" content="${ogType}" />
<meta property="og:site_name" content="${escapeHtml(SITE.name)}" />
<meta property="og:title" content="${title}" />
<meta property="og:description" content="${description}" />
<meta property="og:url" content="${url}" />
<meta property="og:locale" content="${OG_LOCALES[locale]}" />
<meta property="og:image" content="${ogImage}" />
<meta property="og:image:type" content="image/png" />
<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />
<meta property="og:image:alt" content="${title}" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="${title}" />
<meta name="twitter:description" content="${description}" />
<meta name="twitter:image" content="${ogImage}" />
<meta name="twitter:image:alt" content="${title}" />
${ANALYTICS}
${schema}`;
}
function renderDemoHead(siteUrl2) {
  const url = absolute(siteUrl2, "/demo/");
  return `<title>Try a sample comic - CBZ Reader</title>
<meta name="description" content="Read a short public-domain comic in the browser. No file needed, nothing uploaded." />
<link rel="canonical" href="${url}" />
<meta name="robots" content="noindex,nofollow" />
<meta name="theme-color" content="${THEME_COLORS.light}" />
${themeScript()}
<link rel="manifest" href="/manifest.webmanifest" />
<link rel="manifest" href="/manifest-dark.webmanifest" media="(prefers-color-scheme: dark)" />
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
${ANALYTICS}`;
}
const siteUrl = globalThis.__SITE_URL__ ?? "https://your-domain.com";
function englishAlternates(path) {
  return [
    { hreflang: "en", path },
    { hreflang: "x-default", path }
  ];
}
const routes = [
  ...PAGES.map((page) => ({
    path: page.path,
    lang: htmlLang("en"),
    alternates: page.path === "/" ? HOME_ALTERNATES : englishAlternates(page.path)
  })),
  ...["zh", "ja"].map((locale) => ({
    path: LOCALIZED_HOME_PAGES[locale].path,
    lang: htmlLang(locale),
    alternates: HOME_ALTERNATES
  })),
  // A device-testing entry: prerendered so it works without JS, but kept out
  // of the sitemap and marked noindex.
  { path: "/demo/", lang: htmlLang("en"), alternates: [], noindex: true }
];
function pageForPath(path) {
  if (path === "/zh/") return LOCALIZED_HOME_PAGES.zh;
  if (path === "/ja/") return LOCALIZED_HOME_PAGES.ja;
  return findPage(path);
}
function localeForPath(path) {
  if (path === "/zh/") return "zh";
  if (path === "/ja/") return "ja";
  return "en";
}
async function renderPage(path) {
  if (path === "/demo/") {
    const demo = createSSRApp({ render: () => h(DemoPage) });
    return { html: await renderToString(demo), head: renderDemoHead(siteUrl) };
  }
  const page = pageForPath(path);
  const route = routes.find((item) => item.path === path) ?? routes[0];
  const locale = localeForPath(path);
  const siteI18n = createSiteI18n(locale);
  const app = createSSRApp({
    render: () => h(_sfc_main, { page })
  });
  app.use(siteI18n);
  const html = await renderToString(app);
  return {
    html,
    head: renderHead(page, siteUrl, { locale, alternates: route.alternates })
  };
}
export {
  renderPage,
  routes
};
